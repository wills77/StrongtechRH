import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HomeView from './components/HomeView';
import JobsView from './components/JobsView';
import CandidateView from './components/CandidateView';
import DashboardView from './components/DashboardView';
import JobManagerView from './components/JobManagerView';
import CandidatesListView from './components/CandidatesListView';
import CalendarView from './components/CalendarView';
import MessagesView from './components/MessagesView';
import ContactView from './components/ContactView';
import Footer from './components/Footer';

import {
  UserRole,
  Job,
  CandidateProfile,
  Application,
  CalendarEvent,
  Notification,
  ChatSession,
  ChatMessage
} from './types';

import {
  initialJobs,
  initialCandidateProfile,
  initialCandidatesList,
  initialApplications,
  initialCalendarEvents,
  initialNotifications,
  initialChatSessions
} from './data/mockData';

export default function App() {
  // Global States with localStorage sync for persistence:
  const [role, setRole] = useState<UserRole>(() => {
    const saved = localStorage.getItem('strongtech_role');
    return (saved as UserRole) || 'candidate';
  });

  const [activeTab, setActiveTab] = useState<string>(() => {
    const saved = localStorage.getItem('strongtech_tab');
    return saved || 'home';
  });

  const [jobs, setJobs] = useState<Job[]>(() => {
    const saved = localStorage.getItem('strongtech_jobs');
    return saved ? JSON.parse(saved) : initialJobs;
  });

  const [profile, setProfile] = useState<CandidateProfile>(() => {
    const saved = localStorage.getItem('strongtech_profile');
    return saved ? JSON.parse(saved) : initialCandidateProfile;
  });

  const [candidates, setCandidates] = useState<CandidateProfile[]>(() => {
    const saved = localStorage.getItem('strongtech_candidates');
    return saved ? JSON.parse(saved) : initialCandidatesList;
  });

  const [applications, setApplications] = useState<Application[]>(() => {
    const saved = localStorage.getItem('strongtech_applications');
    return saved ? JSON.parse(saved) : initialApplications;
  });

  const [events, setEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem('strongtech_events');
    return saved ? JSON.parse(saved) : initialCalendarEvents;
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem('strongtech_notifications');
    return saved ? JSON.parse(saved) : initialNotifications;
  });

  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('strongtech_chats');
    return saved ? JSON.parse(saved) : initialChatSessions;
  });

  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('strongtech_darkmode');
    return saved === 'true';
  });

  const [scrollUpVisible, setScrollUpVisible] = useState(false);

  // Sync state modifications to localStorage
  useEffect(() => {
    localStorage.setItem('strongtech_role', role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem('strongtech_tab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    localStorage.setItem('strongtech_jobs', JSON.stringify(jobs));
  }, [jobs]);

  useEffect(() => {
    localStorage.setItem('strongtech_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('strongtech_candidates', JSON.stringify(candidates));
  }, [candidates]);

  useEffect(() => {
    localStorage.setItem('strongtech_applications', JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem('strongtech_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('strongtech_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('strongtech_chats', JSON.stringify(chatSessions));
  }, [chatSessions]);

  useEffect(() => {
    localStorage.setItem('strongtech_darkmode', String(darkMode));
    if (darkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [darkMode]);

  // Monitor scroll for Scroll-To-Top button
  useEffect(() => {
    const handleScroll = () => {
      setScrollUpVisible(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Central functions to handle events
  const handleApply = (jobId: string, coverLetter: string, cvFileName: string) => {
    const matchedJob = jobs.find(j => j.id === jobId);
    if (!matchedJob) return;

    // Append new application
    const newApp: Application = {
      id: `app-${Date.now()}`,
      jobId,
      jobTitle: matchedJob.title,
      company: matchedJob.company,
      candidateId: profile.id,
      candidateName: profile.fullName,
      candidateEmail: profile.email,
      dateApplied: new Date().toISOString().split('T')[0],
      status: 'Reçue',
      coverLetter,
      cvFileName
    };

    setApplications(prev => [newApp, ...prev]);

    // Create a new notification
    const newNotif: Notification = {
      id: `notif-${Date.now()}`,
      title: 'Nouvelle candidature',
      description: `${profile.fullName} a postulé au poste de ${matchedJob.title}.`,
      date: new Date().toISOString().split('T')[0],
      read: false,
      type: 'application'
    };

    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleUpdateProfile = (updatedProfile: CandidateProfile) => {
    setProfile(updatedProfile);
    // Also sync candidate list with user updates so HR is instantly updated
    setCandidates(prev => 
      prev.map(c => c.id === updatedProfile.id ? updatedProfile : c)
    );
  };

  const handleAddJob = (newJobData: Omit<Job, 'id' | 'publishedDate'>) => {
    const newJob: Job = {
      ...newJobData,
      id: `job-${Date.now()}`,
      publishedDate: new Date().toISOString().split('T')[0]
    };
    setJobs(prev => [newJob, ...prev]);

    // Create Notification
    const newNotif: Notification = {
      id: `notif-${Date.now()}`,
      title: 'Nouvelle Offre',
      description: `L'offre d'emploi pour "${newJob.title}" est maintenant active.`,
      date: new Date().toISOString().split('T')[0],
      read: false,
      type: 'new_candidate'
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleUpdateJob = (modifiedJob: Job) => {
    setJobs(prev => prev.map(j => j.id === modifiedJob.id ? modifiedJob : j));
  };

  const handleDeleteJob = (jobId: string) => {
    setJobs(prev => prev.filter(j => j.id !== jobId));
  };

  const handleAddCalendarEvent = (newEventData: Omit<CalendarEvent, 'id'>) => {
    const newEvent: CalendarEvent = {
      ...newEventData,
      id: `evt-${Date.now()}`
    };
    setEvents(prev => [newEvent, ...prev]);

    // Create Notification
    const newNotif: Notification = {
      id: `notif-${Date.now()}`,
      title: 'Entretien Planifié',
      description: `Rendez-vous fixé pour "${newEvent.title}" le ${newEvent.date} à ${newEvent.time}.`,
      date: new Date().toISOString().split('T')[0],
      read: false,
      type: 'interview'
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleDeleteCalendarEvent = (eventId: string) => {
    setEvents(prev => prev.filter(e => e.id !== eventId));
  };

  const handleSendMessage = (sessionId: string, text: string, senderId: 'candidate' | 'hr') => {
    setChatSessions(prev => 
      prev.map(session => {
        if (session.id !== sessionId) return session;

        const senderName = senderId === 'candidate' ? profile.fullName : 'Cabinet Conseil Strongtech';
        
        const newMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          senderId,
          senderName,
          text,
          timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
        };

        return {
          ...session,
          lastMessage: text,
          lastUpdated: 'À l\'instant',
          unread: senderId === 'candidate', // if candidate sends, mark unread for HR
          messages: [...session.messages, newMsg]
        };
      })
    );
  };

  const handleMarkRead = (sessionId: string) => {
    setChatSessions(prev => 
      prev.map(s => s.id === sessionId ? { ...s, unread: false } : s)
    );
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Redirect HR "Contacter" click directly to the Chat session linked to the Candidate
  const handleStartChatFromCandidatesList = (candidateId: string) => {
    // Find or simulate corresponding thread session
    const existing = chatSessions.find(s => s.candidateId === candidateId);
    if (existing) {
      setActiveSessionId(existing.id);
      setActiveTab('messages');
    } else {
      // Create new session if none exists
      const targetCandidate = candidates.find(c => c.id === candidateId);
      if (!targetCandidate) return;

      const newSession: ChatSession = {
        id: `chat-${Date.now()}`,
        candidateId,
        candidateName: targetCandidate.fullName,
        candidatePhotoUrl: targetCandidate.photoUrl,
        candidateTitle: targetCandidate.title,
        lastMessage: 'Début de votre conversation.',
        lastUpdated: 'À l\'instant',
        unread: false,
        messages: []
      };

      setChatSessions(prev => [newSession, ...prev]);
      setActiveSessionId(newSession.id);
      setActiveTab('messages');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Render sub page depending on current navigation
  const renderActiveView = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeView
            onNavigate={setActiveTab}
            onSetRole={setRole}
            totalJobs={jobs.filter(j => j.status === 'active').length}
            totalCandidates={candidates.length}
            totalApplications={applications.length}
          />
        );
      case 'jobs':
        return (
          <JobsView
            jobs={jobs}
            role={role}
            appliedJobIds={applications.map(app => app.jobId)}
            onApply={handleApply}
          />
        );
      case 'profile':
        return (
          <CandidateView
            profile={profile}
            applications={applications}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'dashboard':
        return (
          <DashboardView
            jobs={jobs}
            candidates={candidates}
            applications={applications}
            events={events}
            onNavigate={setActiveTab}
          />
        );
      case 'job-manager':
        return (
          <JobManagerView
            jobs={jobs}
            onAddJob={handleAddJob}
            onUpdateJob={handleUpdateJob}
            onDeleteJob={handleDeleteJob}
          />
        );
      case 'candidates':
        return (
          <CandidatesListView
            candidates={candidates}
            onAddCalendarEvent={handleAddCalendarEvent}
            onStartChat={handleStartChatFromCandidatesList}
          />
        );
      case 'calendar':
        return (
          <CalendarView
            events={events}
            onAddEvent={handleAddCalendarEvent}
            onDeleteEvent={handleDeleteCalendarEvent}
          />
        );
      case 'messages':
        return (
          <MessagesView
            chatSessions={chatSessions}
            activeSessionId={activeSessionId}
            role={role}
            onSendMessage={handleSendMessage}
            onSetActiveSession={setActiveSessionId}
            onMarkRead={handleMarkRead}
          />
        );
      case 'contact':
        return <ContactView />;
      default:
        return <div>Introuvable</div>;
    }
  };

  const getPageDisplayTitle = () => {
    switch (activeTab) {
      case 'home':
        return {
          title: "Portail d'Acquisition StrongtechRH",
          subtitle: "L'intelligence artificielle au service de vos recrutements et de l'onboarding candidat."
        };
      case 'jobs':
        return {
          title: "Opportunités de Carrière",
          subtitle: "Consultez les offres d'emploi actives et postulez en quelques clics."
        };
      case 'profile':
        return {
          title: "Mon Espace Candidat",
          subtitle: "Organisez votre profil professionnel, CV et suivez l'avancement de vos dossiers."
        };
      case 'dashboard':
        return {
          title: "Tableau de Bord RH ATS",
          subtitle: "Statistiques consolidées, KPIs d'intégration et funnel de recrutement."
        };
      case 'job-manager':
        return {
          title: "Gestionnaire d'Offres d'Emploi",
          subtitle: "Créez, éditez et diffusez de nouveaux postes d'ingénierie et de support."
        };
      case 'candidates':
        return {
          title: "Vivier de Talents",
          subtitle: "Parcourez les profils d'exception enregistrés et initiez les prises de contact."
        };
      case 'calendar':
        return {
          title: "Calendrier & Agenda Recruteur",
          subtitle: "Gérez vos entretiens d'embauche, revues collégiales et sessions de vetting."
        };
      case 'messages':
        return {
          title: "Messagerie Collaborative",
          subtitle: "Canaux de communication unifiés entre postulants et recruteurs."
        };
      case 'contact':
        return {
          title: "Formulaire d'Aide & Support",
          subtitle: "Une question ou suggestion technique concernant l'ATS ? Contactez nos équipes."
        };
      default:
        return {
          title: "StrongtechRH",
          subtitle: "Le futur des ressources humaines."
        };
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col lg:flex-row transition-colors duration-200">
      
      {/* SIDEBAR ON DESKTOP & TOP NAV ON MOBILE */}
      <Navbar
        role={role}
        onSetRole={setRole}
        activeTab={activeTab}
        onNavigate={setActiveTab}
        notifications={notifications}
        onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        profile={profile}
      />

      {/* RIGHT SIDE MAIN VIEW AREA */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0">
        
        {/* PERSPECTIVE WARNING NOTICE DESKTOP */}
        <div className="bg-[#0F4C81] dark:bg-slate-900 border-b border-[#0A3B68] text-white py-2.5 text-center text-[11px] sm:text-xs font-semibold px-4 flex items-center justify-center gap-2">
          <span className="bg-emerald-400 text-[#0F4C81] font-mono px-1.5 py-0.5 rounded text-[10px] uppercase font-bold tracking-tight shrink-0">Mode Simulateur</span>
          <span>Utilisez les boutons de changement d'Espace & de Rôle en haut ou à gauche pour tester l'onboarding complet !</span>
        </div>

        {/* HIGHLIGHTED PROFESSIONAL UTILITY HEADER */}
        <header className="hidden lg:flex items-center justify-between h-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 flex-shrink-0 select-none transition-colors">
          <div>
            <h1 className="text-xl font-bold font-display text-slate-800 dark:text-white">
              {getPageDisplayTitle().title}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {getPageDisplayTitle().subtitle}
            </p>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 font-mono">
              Role actif : <span className="bg-emerald-400/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded font-bold uppercase">{role === 'hr' ? 'Backoffice RH / ATS' : 'Candidat Externe'}</span>
            </span>
            <div className="h-6 w-px bg-slate-200 dark:bg-slate-800" />
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#0F4C81] text-white flex items-center justify-center font-bold text-sm tracking-tight shadow-md shadow-strong-500/15 font-display shrink-0">
                {role === 'hr' ? 'JD' : profile.fullName.charAt(0)}
              </div>
              <div className="text-left leading-tight hidden xl:block">
                <p className="text-xs font-bold text-slate-800 dark:text-white truncate max-w-[130px]">
                  {role === 'hr' ? 'Jean Dupont' : profile.fullName}
                </p>
                <p className="text-[10px] text-slate-400 font-mono">
                  {role === 'hr' ? 'Administrateur RH' : 'Candidat inscrit'}
                </p>
              </div>
            </div>
          </div>
        </header>

        {/* CENTRAL SCENE VIEW */}
        <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex-1">
          {renderActiveView()}
        </main>

        <Footer onNavigate={setActiveTab} />
      </div>

      {/* SCROLL BACK TO TOP BUTTON */}
      {scrollUpVisible && (
        <button
          onClick={scrollToTop}
          style={{ zIndex: 100 }}
          className="fixed bottom-6 right-6 p-3 rounded-full bg-strong-500 hover:bg-strong-600 shadow-xl text-white outline-hidden cursor-pointer transition-transform hover:-translate-y-1 active:scale-95"
        >
          ▲
        </button>
      )}

    </div>
  );
}
