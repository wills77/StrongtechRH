import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, MapPin, DollarSign, Calendar, SlidersHorizontal, Eye, Paperclip, CheckCircle, ArrowRight, UserCheck, RefreshCw, X, ShieldAlert } from 'lucide-react';
import { Job, Application, UserRole } from '../types';

interface JobsViewProps {
  jobs: Job[];
  role: UserRole;
  appliedJobIds: string[];
  onApply: (jobId: string, coverLetter: string, cvFileName: string) => void;
}

export default function JobsView({ jobs, role, appliedJobIds, onApply }: JobsViewProps) {
  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('all');
  const [selectedContract, setSelectedContract] = useState('all');
  const [selectedExperience, setSelectedExperience] = useState('all');
  const [minSalary, setMinSalary] = useState(15000);
  const [teleworkOnly, setTeleworkOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  // Selected Job Details modal
  const [activeJob, setActiveJob] = useState<Job | null>(null);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [customCVName, setCustomCVName] = useState('Mon_CV_Premium.pdf');
  const [cvFileSelected, setCvFileSelected] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [applicationSuccess, setApplicationSuccess] = useState(false);

  // Extract cities for selector
  const citiesList = useMemo(() => {
    const list = new Set(jobs.map(j => j.city));
    return ['all', ...Array.from(list)];
  }, [jobs]);

  // Handle filtering logic in pure JS
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      if (job.status !== 'active') return false;

      // Search Query matches Title, Company, Description or Skills
      const matchesSearch = searchQuery === '' || 
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.requirements.some(req => req.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCity = selectedCity === 'all' || job.city === selectedCity;
      const matchesContract = selectedContract === 'all' || job.contractType === selectedContract;
      const matchesExperience = selectedExperience === 'all' || job.experienceLevel === selectedExperience;
      
      // Salary check
      const matchesSalary = job.salaryMax >= minSalary;

      // Telework check
      const matchesTelework = !teleworkOnly || job.telework;

      return matchesSearch && matchesCity && matchesContract && matchesExperience && matchesSalary && matchesTelework;
    });
  }, [jobs, searchQuery, selectedCity, selectedContract, selectedExperience, minSalary, teleworkOnly]);

  // Handle Drag & Drop simulation
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setCustomCVName(e.dataTransfer.files[0].name);
      setCvFileSelected(true);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setCustomCVName(e.target.files[0].name);
      setCvFileSelected(true);
    }
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCity('all');
    setSelectedContract('all');
    setSelectedExperience('all');
    setMinSalary(15000);
    setTeleworkOnly(false);
  };

  const submitApplication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeJob) return;
    
    // Call centralized apply routine
    onApply(activeJob.id, coverLetter, customCVName);
    
    setApplicationSuccess(true);
    setTimeout(() => {
      setApplicationSuccess(false);
      setShowApplyModal(false);
      setCoverLetter('');
      setCvFileSelected(false);
      setActiveJob(null);
    }, 2000);
  };

  return (
    <div className="space-y-8 text-left">
      {/* Header and Quick Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="font-display text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
            Offres d'Emplois Disponibles
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            {filteredJobs.length} {filteredJobs.length > 1 ? "offres correspondent" : "offre correspond"} à vos critères sur {jobs.length} postes actifs.
          </p>
        </div>

        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-semibold cursor-pointer active:scale-95 transition-all
            ${showFilters 
              ? 'bg-strong-500 text-white border-strong-500' 
              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-800'
            }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          {showFilters ? 'Fermer les filtres' : 'Filtres avancés'}
        </button>
      </div>

      {/* Modern Filter Board */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
          {/* Main search input */}
          <div className="relative md:col-span-6 lg:col-span-5">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              placeholder="Métier, mot-clé, compétence ou entreprise..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-strong-500 focus:bg-white dark:focus:bg-slate-900/60 transition-all text-sm"
            />
          </div>

          {/* Quick filters - City */}
          <div className="md:col-span-3 lg:col-span-3">
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-strong-500 text-sm capitalize"
            >
              <option value="all">Toutes les villes</option>
              {citiesList.filter(c => c !== 'all').map(city => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </div>

          {/* Quick filters - ContractType */}
          <div className="md:col-span-3 lg:col-span-2">
            <select
              value={selectedContract}
              onChange={(e) => setSelectedContract(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-strong-500 text-sm"
            >
              <option value="all">Secteur Contrat</option>
              <option value="CDI">CDI</option>
              <option value="CDD">CDD</option>
              <option value="Stage">Stage</option>
              <option value="Freelance">Freelance</option>
              <option value="Alternance">Alternance</option>
            </select>
          </div>

          {/* Reset Action */}
          <div className="md:col-span-12 lg:col-span-2">
            <button
              onClick={handleResetFilters}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer bg-slate-50 dark:bg-slate-800/20"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Réinitialiser
            </button>
          </div>
        </div>

        {/* Collapsible Advanced Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {/* Salary Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-500">
                  <span>Salaire minimum</span>
                  <span className="text-strong-500 font-mono">{minSalary.toLocaleString()} € / an</span>
                </div>
                <input
                  type="range"
                  min="12000"
                  max="100000"
                  step="5000"
                  value={minSalary}
                  onChange={(e) => setMinSalary(parseInt(e.target.value))}
                  className="w-full accent-strong-500 h-1.5 bg-slate-200 dark:bg-slate-850 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>12k €</span>
                  <span>50k €</span>
                  <span>100k €</span>
                </div>
              </div>

              {/* Experience dropdown */}
              <div className="space-y-2 text-left">
                <label className="text-xs font-semibold text-slate-500">Niveau d'expérience requis</label>
                <select
                  value={selectedExperience}
                  onChange={(e) => setSelectedExperience(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-strong-500 text-sm"
                >
                  <option value="all">Tous les niveaux d'expérience</option>
                  <option value="Junior">Junior (Débutant / Ecoles)</option>
                  <option value="Intermédiaire">Intermédiaire (2-5 ans)</option>
                  <option value="Senior">Senior (5-8 ans)</option>
                  <option value="Expert">Expert (&gt; 8 ans / Direction)</option>
                </select>
              </div>

              {/* Telework Checkbox */}
              <div className="flex items-center gap-3.5 pt-4 md:pt-6">
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={teleworkOnly}
                    onChange={(e) => setTeleworkOnly(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 dark:bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-strong-500" />
                  <span className="ml-3 text-xs font-semibold text-slate-600 dark:text-slate-300">Télétravail autorisé uniquement</span>
                </label>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Main Jobs Listing Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job) => {
            const isApplied = appliedJobIds.includes(job.id);
            return (
              <motion.div
                key={job.id}
                layout
                whileHover={{ y: -4 }}
                className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition-all relative overflow-hidden"
              >
                {/* Visual Accent */}
                <div className="absolute top-0 left-0 w-full h-1 bg-linear-to-r from-strong-550 to-strong-400 opacity-5" />

                {/* Job Info */}
                <div className="space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <span className="text-[10px] font-bold py-0.5 px-2.5 rounded bg-strong-500/10 text-strong-600 dark:text-strong-400 tracking-wide font-mono uppercase">
                      {job.contractType}
                    </span>
                    {job.telework && (
                      <span className="text-[10px] font-bold py-0.5 px-2 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-mono">
                        Télétravail
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="font-display font-bold text-base text-slate-900 dark:text-white leading-tight hover:text-strong-500 transition-colors line-clamp-2 min-h-[44px]">
                      {job.title}
                    </h3>
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                      {job.company}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-400 font-medium pb-2 border-b border-slate-50 dark:border-slate-800">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {job.city}
                    </span>
                    <span className="flex items-center gap-1 font-mono">
                      <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                      {job.salaryMin.toLocaleString()} - {job.salaryMax.toLocaleString()} €
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-3">
                    {job.shortDescription}
                  </p>

                  <div className="flex flex-wrap gap-1 pt-1">
                    {job.requirements.slice(0, 3).map((req, i) => (
                      <span key={i} className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">
                        {req}
                      </span>
                    ))}
                    {job.requirements.length > 3 && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-50 dark:bg-slate-800/80 text-slate-400">
                        +{job.requirements.length - 3}
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-4 mt-4 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between gap-2.5">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3" />
                    Publié: {job.publishedDate}
                  </span>

                  <button
                    onClick={() => setActiveJob(job)}
                    className="inline-flex items-center gap-1 text-xs font-bold text-strong-500 hover:text-strong-600 transition-colors cursor-pointer group"
                  >
                    Voir l'offre
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                  </button>
                </div>
              </motion.div>
            );
          })
        ) : (
          <div className="col-span-full py-16 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-8 h-8 text-slate-400" />
            </div>
            <div className="space-y-1 max-w-sm mx-auto">
              <h3 className="font-display font-bold text-md text-slate-800 dark:text-white">Aucun poste trouvé</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Ajustez vos filtres de recherche, baissez le salaire requis ou élargissez le type de contrat pour voir d'autres opportunités.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Side Sheet Modal for Job Details & Applying */}
      <AnimatePresence>
        {activeJob && (
          <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (!showApplyModal) setActiveJob(null);
              }}
              className="absolute inset-0 bg-black/60 cursor-pointer"
            />

            {/* Sliding Drawer Body */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 26, stiffness: 220 }}
              className="relative w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col justify-between overflow-y-auto no-print border-l border-slate-100 dark:border-slate-800"
            >
              {/* Sliding Drawer Header */}
              <div className="p-6 border-b border-slate-150 dark:border-slate-800 sticky top-0 bg-white dark:bg-slate-900 z-10 flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-bold py-0.5 px-2 bg-strong-500/15 text-strong-600 dark:text-strong-400 tracking-wider font-mono rounded uppercase">
                    {activeJob.contractType}
                  </span>
                  <h3 className="font-display font-extrabold text-xl text-slate-900 dark:text-white mt-2 leading-snug">
                    {activeJob.title}
                  </h3>
                  <p className="text-xs font-semibold text-strong-500 mt-1">
                    {activeJob.company} — <span className="text-slate-400 font-normal">{activeJob.city}</span>
                  </p>
                </div>
                
                <button
                  onClick={() => {
                    setActiveJob(null);
                    setShowApplyModal(false);
                  }}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-pointer transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Sliding Drawer Content */}
              <div className="p-6 space-y-6 flex-1 text-left">
                {/* Details Pills Grid */}
                <div className="grid grid-cols-2 gap-4 bg-slate-50 dark:bg-slate-850 p-4 rounded-xl text-xs">
                  <div>
                    <span className="text-slate-400 uppercase tracking-wider font-semibold text-[9px]">Salaire annuel prévu</span>
                    <p className="font-bold font-mono text-slate-800 dark:text-slate-200 mt-0.5">
                      {activeJob.salaryMin.toLocaleString()} - {activeJob.salaryMax.toLocaleString()} €
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 uppercase tracking-wider font-semibold text-[9px]">Niveau d'expérience requis</span>
                    <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                      Niveau {activeJob.experienceLevel}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 uppercase tracking-wider font-semibold text-[9px]">Modalité de travail</span>
                    <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                      {activeJob.telework ? 'Télétravail Autorisé' : 'Présentiel Obligatoire'}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 uppercase tracking-wider font-semibold text-[9px]">Date de parution</span>
                    <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5 font-mono">
                      {activeJob.publishedDate}
                    </p>
                  </div>
                </div>

                {/* Job Description Block */}
                <div className="space-y-2.5">
                  <h4 className="font-display font-bold text-sm text-slate-800 dark:text-white uppercase tracking-wider text-[11px]">Description du poste</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-350 leading-relaxed font-normal whitespace-pre-line">
                    {activeJob.description}
                  </p>
                </div>

                {/* Skills Block */}
                <div className="space-y-2.5">
                  <h4 className="font-display font-bold text-sm text-slate-800 dark:text-white uppercase tracking-wider text-[11px]">Compétences & Technologies recherchées</h4>
                  <div className="flex flex-wrap gap-2">
                    {activeJob.requirements.map((skill, index) => (
                      <span key={index} className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Simulated Warning */}
                <div className="p-3.5 rounded-lg border border-amber-100 dark:border-amber-950/20 bg-amber-500/5 text-[11px] text-amber-700 dark:text-amber-400/80 leading-relaxed">
                  En postulant à cette offre fictive, une demande sera immédiatement transmise au <strong>Tableau de Bord RH</strong> et simulée pour tester l'onboarding complet de l'ATS StrongtechRH.
                </div>
              </div>

              {/* Drawer Action Bar */}
              <div className="p-6 border-t border-slate-150 dark:border-slate-800 sticky bottom-0 bg-white dark:bg-slate-900 z-10">
                <AnimatePresence mode="wait">
                  {!showApplyModal ? (
                    <motion.div
                      key="btn-apply-step"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                    >
                      {appliedJobIds.includes(activeJob.id) ? (
                        <div className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 font-bold text-sm text-center">
                          <CheckCircle className="w-4.5 h-4.5" />
                          Vous avez déjà postulé à ce poste
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            if (role !== 'candidate') {
                              alert("Veuillez switcher de rôle pour 'Candidat' (depuis la barre de navigation du haut) pour postuler.");
                              return;
                            }
                            setShowApplyModal(true);
                          }}
                          className="w-full py-3.5 rounded-xl bg-strong-500 hover:bg-strong-600 text-white font-bold text-sm tracking-wide shadow-md active:scale-95 transition-all cursor-pointer text-center"
                        >
                          Postuler maintenant
                        </button>
                      )}
                    </motion.div>
                  ) : (
                    <motion.form
                      key="form-apply-step"
                      onSubmit={submitApplication}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-4"
                    >
                      {/* Form Details */}
                      <div className="space-y-3.5 text-left">
                        <div className="flex justify-between items-center">
                          <h5 className="font-display font-bold text-xs uppercase tracking-wider text-slate-500">Formulaire de candidature</h5>
                          <button
                            type="button"
                            onClick={() => setShowApplyModal(false)}
                            className="text-xs text-strong-500 hover:underline cursor-pointer"
                          >
                            Retour aux détails
                          </button>
                        </div>

                        {/* File Upload Drag-and-Drop */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-semibold text-slate-500">Déposer mon CV (obligatoire)</label>
                          <div
                            onDragEnter={handleDrag}
                            onDragOver={handleDrag}
                            onDragLeave={handleDrag}
                            onDrop={handleDrop}
                            onClick={() => document.getElementById('cv-file-picker')?.click()}
                            className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2
                              ${dragActive 
                                ? 'border-strong-500 bg-strong-500/5' 
                                : cvFileSelected 
                                  ? 'border-emerald-500 bg-emerald-500/5' 
                                  : 'border-slate-200 dark:border-slate-800 hover:border-strong-300 bg-slate-50 dark:bg-slate-850'
                              }`}
                          >
                            <input
                              id="cv-file-picker"
                              type="file"
                              accept=".pdf,.doc,.docx"
                              onChange={handleFileChange}
                              className="hidden"
                            />
                            <Paperclip className={`w-6 h-6 ${cvFileSelected ? 'text-emerald-500' : 'text-slate-400'}`} />
                            <div className="text-xs">
                              {cvFileSelected ? (
                                <p className="font-bold text-emerald-600 dark:text-emerald-400">{customCVName}</p>
                              ) : (
                                <p className="text-slate-500"><strong className="text-strong-550 dark:text-strong-400">Glissez-déposez</strong> un fichier ou cliquez ici (Simulé)</p>
                              )}
                              <p className="text-[10px] text-slate-400 mt-1">Format PDF, DOCX (Max. 5 Mo). Un fichier d'exemple est pré-sélectionné.</p>
                            </div>
                          </div>
                        </div>

                        {/* Cover Letter Input */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-semibold text-slate-500">Lettre de motivation (optionnelle)</label>
                          <textarea
                            placeholder="Écrivez un message court pour le recruteur..."
                            value={coverLetter}
                            onChange={(e) => setCoverLetter(e.target.value)}
                            rows={3}
                            className="w-full text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 placeholder-slate-400 font-normal focus:outline-none focus:ring-2 focus:ring-strong-500 focus:bg-white dark:focus:bg-slate-900 transition-all"
                          />
                        </div>
                      </div>

                      {/* Apply Submission Trigger */}
                      <AnimatePresence mode="wait">
                        {applicationSuccess ? (
                          <motion.div
                            key="apply-success-box"
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="flex items-center justify-center gap-1.5 py-3 rounded-xl bg-emerald-500 text-white text-xs font-extrabold"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Candidature déposée avec succès !
                          </motion.div>
                        ) : (
                          <button
                            type="submit"
                            className="w-full py-3.5 rounded-xl bg-strong-500 hover:bg-strong-600 text-white font-bold text-sm tracking-wide active:scale-95 transition-all text-center cursor-pointer"
                          >
                            Soumettre ma candidature
                          </button>
                        )}
                      </AnimatePresence>
                    </motion.form>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
