import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, Bell, Sun, Moon, Sparkles, User, Settings, Info, Menu, X, Mail, CheckCircle,
  Home, LayoutDashboard, Calendar, Users, MessageSquare, Layers
} from 'lucide-react';
import { UserRole, Notification, CandidateProfile } from '../types';

interface NavbarProps {
  role: UserRole;
  onSetRole: (role: UserRole) => void;
  activeTab: string;
  onNavigate: (tab: string) => void;
  notifications: Notification[];
  onMarkAllNotificationsRead: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  profile?: CandidateProfile;
}

export default function Navbar({
  role,
  onSetRole,
  activeTab,
  onNavigate,
  notifications,
  onMarkAllNotificationsRead,
  darkMode,
  onToggleDarkMode,
  profile
}: NavbarProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  // Custom Navigation Links based on selected role
  const getNavLinks = () => {
    const common = [
      { id: 'home', label: 'Accueil' },
      { id: 'jobs', label: 'Offres d\'emploi' },
    ];

    if (role === 'candidate') {
      return [
        ...common,
        { id: 'profile', label: 'Mon Profil & Candidatures' },
        { id: 'messages', label: 'Messagerie' },
        { id: 'contact', label: 'Contact' },
      ];
    } else {
      // HR or Admin
      return [
        ...common,
        { id: 'dashboard', label: 'Tableau de Bord RH' },
        { id: 'job-manager', label: 'Gérer les Offres' },
        { id: 'candidates', label: 'Vivier Candidats' },
        { id: 'calendar', label: 'Calendrier RH' },
        { id: 'messages', label: 'Messagerie' },
        { id: 'contact', label: 'Contact' },
      ];
    }
  };

  const navLinks = getNavLinks();

  const getLinkIcon = (id: string) => {
    switch (id) {
      case 'home':
        return <Home className="w-4 h-4 shrink-0" />;
      case 'jobs':
        return <Briefcase className="w-4 h-4 shrink-0" />;
      case 'profile':
        return <User className="w-4 h-4 shrink-0" />;
      case 'dashboard':
        return <LayoutDashboard className="w-4 h-4 shrink-0" />;
      case 'job-manager':
        return <Sparkles className="w-4 h-4 shrink-0" />;
      case 'candidates':
        return <Users className="w-4 h-4 shrink-0" />;
      case 'calendar':
        return <Calendar className="w-4 h-4 shrink-0" />;
      case 'messages':
        return <MessageSquare className="w-4 h-4 shrink-0" />;
      case 'contact':
        return <Info className="w-4 h-4 shrink-0" />;
      default:
        return <Briefcase className="w-4 h-4 shrink-0" />;
    }
  };

  return (
    <>
      {/* 1. LEFT SIDEBAR FOR DESKTOP SCREENS */}
      <aside className="hidden lg:flex w-72 bg-[#0F4C81] text-white flex-col flex-shrink-0 sticky top-0 h-screen border-r border-[#0A3B68] select-none z-30 justify-between">
        
        {/* Brand Header */}
        <div 
          className="p-6 flex items-center gap-3 border-b border-[#0A3B68] cursor-pointer" 
          onClick={() => onNavigate('home')}
        >
          <div className="w-9 h-9 bg-emerald-450 rounded-xl flex items-center justify-center font-display font-black text-[#0F4C81] text-sm shadow-md animate-pulse shrink-0">
            ST
          </div>
          <div className="text-left text-white">
            <span className="font-display font-black tracking-tight text-lg text-white">
              Strongtech<span className="text-emerald-400">RH</span>
            </span>
            <p className="text-[9px] font-mono font-bold text-emerald-300 tracking-wider">ATS PLATFORM</p>
          </div>
        </div>

        {/* Inner Nav list */}
        <div className="flex-1 flex flex-col gap-1.5 px-4 py-6 overflow-y-auto">
          <p className="text-[9px] px-3 font-semibold font-mono tracking-widest uppercase text-emerald-300/60 mb-2">
            Nouveau Menu {role === 'hr' ? 'Backoffice / ATS' : 'Candidat'}
          </p>
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold cursor-pointer transition-all active:scale-98 text-left group
                  ${isActive
                    ? 'bg-white/10 text-white font-bold border-l-4 border-emerald-400 pl-3'
                    : 'text-white/70 hover:text-white hover:bg-white/5'
                  }`}
              >
                {getLinkIcon(link.id)}
                <span>{link.label}</span>
              </button>
            );
          })}
        </div>

        {/* Sidebar Footer context & Licence Premium layout */}
        <div className="p-5 border-t border-[#0A3B68] space-y-4">
          <div className="bg-[#0a3b68]/50 rounded-xl p-4 border border-white/5 space-y-3">
            <div className="flex items-center justify-between text-[10px] text-white/60">
              <span className="font-bold tracking-wider uppercase">Licence</span>
              <span className="bg-emerald-400/20 text-emerald-300 font-mono text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-tight">
                PRO ACTIVE
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
              <p className="text-xs font-bold text-white truncate max-w-[170px]">
                {role === 'hr' ? 'Jean Dupont (RH / Admin)' : (profile?.fullName || 'Yassine Belkacem')}
              </p>
            </div>

            {/* Simulated progress metric layout representing active quota */}
            <div className="space-y-1">
              <div className="flex justify-between text-[8px] text-white/55 font-mono">
                <span>Rendement / Quotas</span>
                <span>86%</span>
              </div>
              <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
                <div className="bg-emerald-400 h-full w-[86%] rounded-full" />
              </div>
            </div>
          </div>
        </div>

      </aside>

      {/* 2. STICKY TOPBAR FOR TABLETS & PHONES ONLY */}
      <nav className="lg:hidden sticky top-0 z-40 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-100 dark:border-slate-800 transition-colors duration-200 h-16 flex items-center justify-between px-4">
        
        {/* Brand Logo Header */}
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onNavigate('home')}>
          <div className="w-8 h-8 rounded-lg bg-[#0F4C81] text-white flex items-center justify-center font-display font-black text-[11px] shadow-sm">
            ST
          </div>
          <div className="text-left">
            <span className="font-display font-black tracking-tight text-sm text-slate-900 dark:text-white">
              Strongtech<span className="text-strong-500">RH</span>
            </span>
            <p className="text-[8px] font-mono font-medium text-slate-450 tracking-wide">ATS</p>
          </div>
        </div>

        {/* Controls block */}
        <div className="flex items-center gap-2">
          
          {/* Quick Perspective selector button for visual convenience */}
          <button
            onClick={() => {
              const newRole = role === 'candidate' ? 'hr' : 'candidate';
              onSetRole(newRole);
              if (newRole === 'candidate') {
                if (['dashboard', 'job-manager', 'candidates', 'calendar'].includes(activeTab)) {
                  onNavigate('jobs');
                }
              } else {
                if (activeTab === 'profile') {
                  onNavigate('dashboard');
                }
              }
            }}
            className="text-[10px] bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2 py-1.5 rounded-lg text-slate-750 dark:text-slate-350 font-bold active:scale-95 transition-all text-center"
          >
            Vue : <span className="text-strong-500 font-mono uppercase font-black">{role === 'candidate' ? 'Cand' : 'RH'}</span>
          </button>

          {/* Darkmode toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-1.5 rounded-lg border dark:border-slate-800 text-slate-500 active:scale-90"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-550" /> : <Moon className="w-4 h-4 text-slate-550" />}
          </button>

          {/* Alerts Bell notification control */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-550 dark:text-slate-400 cursor-pointer active:scale-90"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-3.5 h-3.5 px-0.5 rounded-full bg-strong-500 text-white font-mono text-[8px] font-bold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notification list popover layer */}
            <AnimatePresence>
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-xl shadow-2xl z-50 overflow-hidden text-left py-2 font-normal">
                  <div className="px-4 py-1.5 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-850/40">
                    <span className="font-display font-extrabold text-[11px] text-slate-900 dark:text-white">Alertes</span>
                    <button
                      onClick={() => {
                        onMarkAllNotificationsRead();
                        setShowNotifications(false);
                      }}
                      className="text-[9px] font-bold text-strong-550 hover:underline"
                    >
                      Tout lu
                    </button>
                  </div>
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-48 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((notif) => (
                        <div key={notif.id} className="p-3 text-[11px] leading-snug">
                          <p className="font-bold text-slate-800 dark:text-white">{notif.title}</p>
                          <p className="text-slate-500 dark:text-slate-400 mt-0.5">{notif.description}</p>
                        </div>
                      ))
                    ) : (
                      <p className="p-3 text-center text-slate-400 text-[10px]">Aucune notification.</p>
                    )}
                  </div>
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* Hamburger control trigger */}
          <button
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 cursor-pointer"
          >
            {showMobileMenu ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>

        </div>
      </nav>

      {/* MOBILE COLLAPSIBLE DRAWER SCREEN HEIGHT */}
      <AnimatePresence>
        {showMobileMenu && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 overflow-hidden sticky top-16 z-35"
          >
            <div className="px-4 py-4 space-y-2 flex flex-col text-left">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    onNavigate(link.id);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl font-semibold text-xs transition-all
                    ${activeTab === link.id
                      ? 'bg-strong-500/10 text-strong-500 font-bold'
                      : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                >
                  <div className="flex items-center gap-2.5">
                    {getLinkIcon(link.id)}
                    <span>{link.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
