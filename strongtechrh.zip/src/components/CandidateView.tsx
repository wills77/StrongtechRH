import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Phone, MapPin, Mail, Award, BookOpen, Clock, Heart, Download, Upload, Plus, Trash2, Edit2, Check, FileText } from 'lucide-react';
import { CandidateProfile, Application, ApplicationStatus } from '../types';

interface CandidateViewProps {
  profile: CandidateProfile;
  applications: Application[];
  onUpdateProfile: (updatedProfile: CandidateProfile) => void;
}

export default function CandidateView({ profile, applications, onUpdateProfile }: CandidateViewProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(profile.fullName);
  const [editedPhone, setEditedPhone] = useState(profile.phone);
  const [editedAddress, setEditedAddress] = useState(profile.address);
  const [editedBio, setEditedBio] = useState(profile.bio);
  const [newSkill, setNewSkill] = useState('');

  // Experience form inputs
  const [expRole, setExpRole] = useState('');
  const [expCompany, setExpCompany] = useState('');
  const [expDuration, setExpDuration] = useState('');
  const [expDesc, setExpDesc] = useState('');
  const [showAddExp, setShowAddExp] = useState(false);

  // Education form inputs
  const [eduDegree, setEduDegree] = useState('');
  const [eduSchool, setEduSchool] = useState('');
  const [eduYear, setEduYear] = useState('');
  const [showAddEdu, setShowAddEdu] = useState(false);

  const handleSaveProfile = () => {
    onUpdateProfile({
      ...profile,
      fullName: editedName,
      phone: editedPhone,
      address: editedAddress,
      bio: editedBio
    });
    setIsEditing(false);
  };

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkill.trim()) return;
    if (profile.skills.includes(newSkill.trim())) {
      setNewSkill('');
      return;
    }
    const updatedSkills = [...profile.skills, newSkill.trim()];
    onUpdateProfile({ ...profile, skills: updatedSkills });
    setNewSkill('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    const updatedSkills = profile.skills.filter(s => s !== skillToRemove);
    onUpdateProfile({ ...profile, skills: updatedSkills });
  };

  const handleAddExperience = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expRole || !expCompany || !expDuration) return;
    const updatedExp = [
      { role: expRole, company: expCompany, duration: expDuration, description: expDesc },
      ...profile.experience
    ];
    onUpdateProfile({ ...profile, experience: updatedExp });
    setExpRole('');
    setExpCompany('');
    setExpDuration('');
    setExpDesc('');
    setShowAddExp(false);
  };

  const handleRemoveExperience = (index: number) => {
    const updatedExp = profile.experience.filter((_, i) => i !== index);
    onUpdateProfile({ ...profile, experience: updatedExp });
  };

  const handleAddEducation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eduDegree || !eduSchool || !eduYear) return;
    const updatedEdu = [
      { degree: eduDegree, school: eduSchool, year: eduYear },
      ...profile.education
    ];
    onUpdateProfile({ ...profile, education: updatedEdu });
    setEduDegree('');
    setEduSchool('');
    setEduYear('');
    setShowAddEdu(false);
  };

  const handleRemoveEducation = (index: number) => {
    const updatedEdu = profile.education.filter((_, i) => i !== index);
    onUpdateProfile({ ...profile, education: updatedEdu });
  };

  // Status badging utilities
  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'Reçue':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
      case 'En cours':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
      case 'Entretien':
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
      case 'Acceptée':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
      case 'Refusée':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20';
      default:
        return 'bg-slate-500/10 text-slate-600 border-slate-500/20';
    }
  };

  // Simulate CV text download
  const downloadSimulatedCV = () => {
    const dataText = `===========================================
CV DE ${profile.fullName.toUpperCase()}
Poste : ${profile.title}
Niveau d'expérience : ${profile.seniority}
Email : ${profile.email} | Tel : ${profile.phone}
Localisation : ${profile.address}
===========================================

BIO :
${profile.bio}

COMPÉTENCES :
${profile.skills.join(', ')}

EXPÉRIENCES :
${profile.experience.map(e => `- ${e.role} chez ${e.company} (${e.duration}) : ${e.description}`).join('\n')}

FORMATIONS :
${profile.education.map(e => `- ${e.degree} à ${e.school} [${e.year}]`).join('\n')}

LANGUES :
${profile.languages.map(l => `- ${l.language} : ${l.level}`).join('\n')}
===========================================
Généré par StrongtechRH le ${new Date().toLocaleDateString('fr-FR')}
`;
    const blob = new Blob([dataText], { type: 'text/plain;charset=utf-8' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `CV_StrongtechRH_${profile.fullName.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(u);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
      
      {/* LEFT COLUMN: PROFILE CARD AND SETTINGS */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs relative overflow-hidden">
          {/* Top banner */}
          <div className="absolute top-0 left-0 w-full h-24 bg-linear-to-r from-strong-500 to-strong-700" />
          
          <div className="relative pt-12 text-center space-y-4">
            <div className="relative inline-block">
              <img
                src={profile.photoUrl}
                alt={profile.fullName}
                className="w-24 h-24 rounded-full border-4 border-white dark:border-slate-900 shadow-md object-cover mx-auto"
              />
              <div className="absolute bottom-0 right-0 p-1.5 rounded-full bg-strong-500 text-white shadow-md border border-white dark:border-slate-900 cursor-pointer hover:bg-strong-600 transition-colors">
                <Upload className="w-3.5 h-3.5" />
              </div>
            </div>

            <div>
              {isEditing ? (
                <input
                  type="text"
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  className="w-full text-center font-display font-bold text-lg px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border"
                />
              ) : (
                <h3 className="font-display font-extrabold text-lg text-slate-900 dark:text-white">
                  {profile.fullName}
                </h3>
              )}
              <p className="text-xs text-strong-500 font-semibold mt-1">
                {profile.title}
              </p>
              <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 font-semibold uppercase tracking-wider font-mono">
                Profil {profile.seniority}
              </span>
            </div>

            {/* Profile Fields */}
            <div className="pt-4 border-t border-slate-50 dark:border-slate-800 space-y-3 text-sm text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="truncate">{profile.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                {isEditing ? (
                  <input
                    type="text"
                    value={editedPhone}
                    onChange={(e) => setEditedPhone(e.target.value)}
                    className="w-full px-2 py-0.5 rounded border text-xs"
                  />
                ) : (
                  <span>{profile.phone}</span>
                )}
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                {isEditing ? (
                  <input
                    type="text"
                    value={editedAddress}
                    onChange={(e) => setEditedAddress(e.target.value)}
                    className="w-full px-2 py-0.5 rounded border text-xs"
                  />
                ) : (
                  <span className="truncate">{profile.address}</span>
                )}
              </div>
              {profile.cvFileName && (
                <div className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-50 dark:bg-slate-850/50 border border-slate-100 dark:border-slate-800 shrink-0 text-xs">
                  <FileText className="w-4 h-4 text-strong-500 shrink-0" />
                  <span className="font-medium truncate flex-1">{profile.cvFileName}</span>
                </div>
              )}
            </div>

            {/* Editing buttons */}
            <div className="pt-2">
              {isEditing ? (
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveProfile}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-strong-500 text-white font-bold text-xs rounded-lg shadow hover:bg-strong-600 transition-colors cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" /> Enregistrer
                  </button>
                  <button
                    onClick={() => {
                      setEditedName(profile.fullName);
                      setEditedPhone(profile.phone);
                      setEditedAddress(profile.address);
                      setEditedBio(profile.bio);
                      setIsEditing(false);
                    }}
                    className="flex-1 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-350 font-bold text-xs rounded-lg hover:bg-slate-200 transition-colors cursor-pointer border border-slate-200 dark:border-slate-700"
                  >
                    Annuler
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => setIsEditing(true)}
                    className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-850/50 text-slate-700 dark:text-slate-200 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Modifier mes infos
                  </button>
                  <button
                    onClick={downloadSimulatedCV}
                    className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Exporter mon CV (TXT)
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* SKILLS CONTAINER */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
          <h4 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-strong-500" />
            Mes Compétences
          </h4>

          {/* List layout */}
          <div className="flex flex-wrap gap-1.5">
            {profile.skills.map((skill, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-lg font-medium bg-slate-50 dark:bg-slate-850 text-slate-600 dark:text-slate-300 border border-slate-100 dark:border-slate-800"
              >
                {skill}
                <button
                  type="button"
                  onClick={() => handleRemoveSkill(skill)}
                  className="p-0.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                >
                  &times;
                </button>
              </span>
            ))}
          </div>

          {/* Add skill form */}
          <form onSubmit={handleAddSkill} className="flex gap-2">
            <input
              type="text"
              placeholder="Ajouter une compétence..."
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-strong-500"
            />
            <button
              type="submit"
              className="p-1.5 rounded-lg bg-strong-500 hover:bg-strong-600 text-white shadow-xs cursor-pointer active:scale-95 transition-all flex items-center justify-center shrink-0"
            >
              <Plus className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* RIGHT COLUMN: DETAILED EXP, EDU, APPLICATIONS */}
      <div className="lg:col-span-8 space-y-6">
        
        {/* BIO & TEXT EDITOR */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-3">
          <h4 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
            <User className="w-4 h-4 text-strong-500" /> Profil Professionnel / Bio
          </h4>
          {isEditing ? (
            <textarea
              value={editedBio}
              onChange={(e) => setEditedBio(e.target.value)}
              rows={4}
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 focus:outline-none focus:ring-2 focus:ring-strong-500 text-sm font-normal"
            />
          ) : (
            <p className="text-sm text-slate-600 dark:text-slate-350 leading-relaxed font-normal whitespace-pre-line">
              {profile.bio}
            </p>
          )}
        </div>

        {/* WORK HISTORY (EXPÉRIENCES) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-5">
          <div className="flex justify-between items-center">
            <h4 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-strong-500" />
              Parcours et Expériences Professionnelles
            </h4>
            <button
              onClick={() => setShowAddExp(!showAddExp)}
              className="inline-flex items-center gap-1 text-xs font-bold text-strong-500 hover:text-strong-650 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter
            </button>
          </div>

          <AnimatePresence>
            {showAddExp && (
              <motion.form
                onSubmit={handleAddExperience}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850/30 space-y-3.5"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Poste occupé</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Développeur React"
                      value={expRole}
                      onChange={(e) => setExpRole(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Entreprise</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Google LLC"
                      value={expCompany}
                      onChange={(e) => setExpCompany(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Durée</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: 2024 - Présent (2 ans)"
                      value={expDuration}
                      onChange={(e) => setExpDuration(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Description succincte</label>
                  <textarea
                    placeholder="Conception, livrables, performances..."
                    value={expDesc}
                    onChange={(e) => setExpDesc(e.target.value)}
                    rows={2}
                    className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                  />
                </div>
                <div className="flex gap-2 justify-end">
                  <button type="submit" className="px-3 py-1.5 bg-strong-500 hover:bg-strong-600 text-white font-bold text-xs rounded-md shadow-xs cursor-pointer">
                    Ajouter l'expérience
                  </button>
                  <button type="button" onClick={() => setShowAddExp(false)} className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs rounded-md cursor pointer border border-slate-250">
                    Annuler
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="relative pl-6 border-l-2 border-slate-100 dark:border-slate-800 space-y-6">
            {profile.experience.map((exp, index) => (
              <div key={index} className="relative group">
                {/* Visual marker */}
                <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full bg-white dark:bg-slate-950 border-2 border-strong-500 shadow-xs group-hover:bg-strong-500 transition-colors" />
                
                <div className="flex justify-between items-start">
                  <div>
                    <h5 className="font-display font-bold text-sm text-slate-850 dark:text-white leading-snug">
                      {exp.role}
                    </h5>
                    <p className="text-[11px] font-semibold text-strong-500 mt-0.5">
                      {exp.company} — <span className="text-slate-400 font-mono font-normal">{exp.duration}</span>
                    </p>
                  </div>
                  
                  <button
                    onClick={() => handleRemoveExperience(index)}
                    className="p-1 rounded text-red-400 hover:bg-red-500/15 hover:text-red-600 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                  {exp.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* EDUCATION & STUDIES (DIPLÔMES) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-5">
          <div className="flex justify-between items-center">
            <h4 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-strong-500" />
              Formations et Diplômes
            </h4>
            <button
              onClick={() => setShowAddEdu(!showAddEdu)}
              className="inline-flex items-center gap-1 text-xs font-bold text-strong-500 hover:text-strong-650 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter
            </button>
          </div>

          <AnimatePresence>
            {showAddEdu && (
              <motion.form
                onSubmit={handleAddEducation}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850/30 space-y-3.5"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Diplôme / Titre</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Master Ingénierie"
                      value={eduDegree}
                      onChange={(e) => setEduDegree(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">École / Etablissement</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Université Paris-Sorbonne"
                      value={eduSchool}
                      onChange={(e) => setEduSchool(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Années scolaires</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: 2018 - 2021"
                      value={eduYear}
                      onChange={(e) => setEduYear(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    />
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <button type="submit" className="px-3 py-1.5 bg-strong-500 hover:bg-strong-600 text-white font-bold text-xs rounded-md shadow-xs cursor-pointer">
                    Ajouter le diplôme
                  </button>
                  <button type="button" onClick={() => setShowAddEdu(false)} className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs rounded-md cursor pointer border border-slate-250">
                    Annuler
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="relative pl-6 border-l-2 border-slate-100 dark:border-slate-800 space-y-6">
            {profile.education.map((edu, index) => (
              <div key={index} className="relative group">
                <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full bg-white dark:bg-slate-950 border-2 border-emerald-500 shadow-xs group-hover:bg-emerald-500 transition-colors" />
                
                <div className="flex justify-between items-start">
                  <div>
                    <h5 className="font-display font-bold text-sm text-slate-850 dark:text-white leading-snug">
                      {edu.degree}
                    </h5>
                    <p className="text-[11px] font-semibold text-emerald-600 mt-0.5">
                      {edu.school} — <span className="text-slate-400 font-mono font-normal">{edu.year}</span>
                    </p>
                  </div>
                  
                  <button
                    onClick={() => handleRemoveEducation(index)}
                    className="p-1 rounded text-red-400 hover:bg-red-500/15 hover:text-red-600 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* APPLICATION TRACKER TABLE */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <h4 className="font-display font-extrabold text-sm text-slate-850 dark:text-white flex items-center gap-2">
            <Heart className="w-4 h-4 text-strong-500" /> Suivi de l'historique des candidatures
          </h4>

          {applications.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 uppercase font-bold tracking-wider">
                    <th className="py-3 px-4 font-semibold">Poste convoité</th>
                    <th className="py-3 px-4 font-semibold">Entreprise</th>
                    <th className="py-3 px-4 font-semibold font-mono">Date</th>
                    <th className="py-3 px-4 font-semibold text-center">Badges Statut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {applications.map((app) => (
                    <tr key={app.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-850/20 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                        {app.jobTitle}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500 dark:text-slate-400 font-medium">
                        {app.company}
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 font-mono">
                        {app.dateApplied}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-block px-2.5 py-1 text-[10px] font-bold uppercase rounded-full border tracking-wide ${getStatusBadge(app.status)}`}>
                          {app.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-8 text-center text-slate-400 border border-dashed rounded-lg text-xs space-y-1">
              <p className="font-bold">Aucune candidature pour le moment</p>
              <p className="text-slate-400/80">Explorez les offres d'emploi pour lancer votre premier dossier de recrutement.</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
