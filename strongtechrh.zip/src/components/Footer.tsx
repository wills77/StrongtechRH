import React from 'react';
import { ShieldCheck, MessageSquare, Briefcase, HelpCircle } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 py-12 px-4 transition-colors duration-200">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 text-left text-xs font-normal text-slate-500 dark:text-slate-400">
        
        {/* Brand details */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-strong-500 text-white flex items-center justify-center font-bold text-xs uppercase font-display">
              ST
            </div>
            <span className="font-display font-extrabold text-sm text-slate-900 dark:text-white">
              Strongtech<span className="text-strong-500">RH</span>
            </span>
          </div>
          <p className="leading-relaxed">
            La solution d'acquisition de talents intelligente, combinant espace de recrutement fluide, ATS complet et suivi d'onboarding transparent.
          </p>
          <p className="font-mono text-[10px] text-slate-400">
            © 2026 StrongtechRH. Tous droits réservés.
          </p>
        </div>

        {/* Candidature services */}
        <div className="space-y-3">
          <h4 className="font-display font-extrabold text-[#0F4C81] dark:text-strong-400 tracking-wider uppercase text-[10px]">Candidats</h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('jobs')} className="hover:text-strong-500 cursor-pointer">
                Rechercher un Emploi
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('profile')} className="hover:text-strong-500 cursor-pointer">
                Créer mon Profil CV
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('messages')} className="hover:text-strong-500 cursor-pointer">
                Messagerie Internes
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('contact')} className="hover:text-strong-500 cursor-pointer">
                Support & Contact
              </button>
            </li>
          </ul>
        </div>

        {/* Recruiting Services */}
        <div className="space-y-3">
          <h4 className="font-display font-extrabold text-[#0F4C81] dark:text-strong-400 tracking-wider uppercase text-[10px]">Espace RH / Recruteurs</h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('dashboard')} className="hover:text-strong-500 cursor-pointer">
                Tableau de Bord RH
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('job-manager')} className="hover:text-strong-500 cursor-pointer">
                Publier & Gérer les Offres
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('candidates')} className="hover:text-strong-500 cursor-pointer">
                Consulter le Vivier Candidats
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('calendar')} className="hover:text-strong-500 cursor-pointer">
                Planifier des Entretiens
              </button>
            </li>
          </ul>
        </div>

        {/* Security / Compliance */}
        <div className="space-y-4">
          <h4 className="font-display font-extrabold text-[#0F4C81] dark:text-strong-400 tracking-wider uppercase text-[10px]">Sécurité & RGPD</h4>
          <p className="leading-relaxed">
            Vos CV et descriptions de postes sont cryptés conformément aux directives européennes de protection des données.
          </p>
          <div className="flex gap-2 items-center text-emerald-600 dark:text-emerald-400 font-bold text-[11px]">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>Serveurs Sécurisés SSL/TLS</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
