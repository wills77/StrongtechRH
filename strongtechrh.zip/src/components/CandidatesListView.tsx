import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Users, Search, Download, Calendar, Mail, FileText, X, Check, Award, MapPin, Briefcase, Plus, Send } from 'lucide-react';
import { CandidateProfile } from '../types';

interface CandidatesListViewProps {
  candidates: CandidateProfile[];
  onAddCalendarEvent: (event: { title: string; type: 'interview' | 'meeting' | 'session'; date: string; time: string; candidateName: string; description: string }) => void;
  onStartChat: (candidateId: string) => void;
}

export default function CandidatesListView({ candidates, onAddCalendarEvent, onStartChat }: CandidatesListViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected candidate detail modal
  const [activeCandidate, setActiveCandidate] = useState<CandidateProfile | null>(null);

  // Interview scheduling modal state
  const [schedulingCandidate, setSchedulingCandidate] = useState<CandidateProfile | null>(null);
  const [interviewDate, setInterviewDate] = useState('2026-06-12');
  const [interviewTime, setInterviewTime] = useState('14:30');
  const [interviewDesc, setInterviewDesc] = useState('Entretien d\'évaluation des compétences techniques et fit d\'équipe.');
  const [schedulingSuccess, setSchedulingSuccess] = useState(false);

  // Search filter
  const filteredCandidates = candidates.filter(cand => {
    const query = searchQuery.toLowerCase();
    return (
      cand.fullName.toLowerCase().includes(query) ||
      cand.title.toLowerCase().includes(query) ||
      cand.skills.some(skill => skill.toLowerCase().includes(query))
    );
  });

  // Simulated CV printer
  const downloadCandidateCV = (cand: CandidateProfile) => {
    const dataText = `===========================================
CV DE ${cand.fullName.toUpperCase()} - Candidate de StrongtechRH
Poste : ${cand.title}
Profil : ${cand.seniority}
Email : ${cand.email} | Tel : ${cand.phone}
Localisation : ${cand.address}
===========================================

BIO :
${cand.bio}

COMPÉTENCES CLÉS :
${cand.skills.join(', ')}

PARCOURS PROFESSIONNEL :
${cand.experience.map(e => `- ${e.role} chez ${e.company} (${e.duration}) : ${e.description}`).join('\n')}

ÉTUDES / DIPLÔMES :
${cand.education.map(e => `- ${e.degree} à ${e.school} [${e.year}]`).join('\n')}

LANGUES PARLÉES :
${cand.languages.map(l => `- ${l.language} (${l.level})`).join('\n')}
===========================================
Document de recrutement - StrongtechRH ATS
`;
    const blob = new Blob([dataText], { type: 'text/plain;charset=utf-8' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `CV_Strongtech_${cand.fullName.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(u);
  };

  const handleCreateInterview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!schedulingCandidate) return;

    onAddCalendarEvent({
      title: `Entretien de Recrutement - ${schedulingCandidate.fullName}`,
      type: 'interview',
      date: interviewDate,
      time: interviewTime,
      candidateName: schedulingCandidate.fullName,
      description: interviewDesc
    });

    setSchedulingSuccess(true);
    setTimeout(() => {
      setSchedulingSuccess(false);
      setSchedulingCandidate(null);
    }, 2000);
  };

  return (
    <div className="space-y-8 text-left">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="font-display text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
            Vivier de Candidats
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            {filteredCandidates.length} {filteredCandidates.length > 1 ? "candidats répertoriés" : "candidat répertorié"} dans l'ATS StrongtechRH.
          </p>
        </div>
      </div>

      {/* SEARCH AND COMPETENCE ENGINE */}
      <div className="relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
          <Search className="w-4 h-4" />
        </span>
        <input
          type="text"
          placeholder="Rechercher un candidat par nom, titre ou mot-clé technologique (ex: React, DevOps, Sourcing...)"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-850 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-strong-500 text-sm"
        />
      </div>

      {/* GALLERY GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCandidates.length > 0 ? (
          filteredCandidates.map((cand) => (
            <motion.div
              key={cand.id}
              layout
              whileHover={{ y: -3 }}
              className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Header avatar/name */}
                <div className="flex items-center gap-3.5">
                  <img
                    src={cand.photoUrl}
                    alt={cand.fullName}
                    className="w-12 h-12 rounded-full object-cover border border-slate-100 dark:border-slate-800"
                  />
                  <div>
                    <h3 className="font-display font-extrabold text-sm text-slate-900 dark:text-white">
                      {cand.fullName}
                    </h3>
                    <p className="text-xs font-semibold text-strong-500">
                      {cand.title}
                    </p>
                    <span className="inline-block px-1.5 py-0.5 rounded text-[9px] bg-slate-55 bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-400 font-bold uppercase tracking-wider font-mono mt-1">
                      EXP: {cand.seniority}
                    </span>
                  </div>
                </div>

                {/* short bio */}
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed">
                  {cand.bio}
                </p>

                {/* skills registry */}
                <div className="space-y-1">
                  <label className="text-[9px] uppercase tracking-wider font-bold text-slate-400 font-mono">Compétences clés</label>
                  <div className="flex flex-wrap gap-1">
                    {cand.skills.slice(0, 4).map((skill, index) => (
                      <span key={index} className="text-[10px] font-semibold px-2 py-0.5 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-800 rounded text-slate-500 dark:text-slate-450">
                        {skill}
                      </span>
                    ))}
                    {cand.skills.length > 4 && (
                      <span className="text-[10px] font-bold text-slate-400">
                        +{cand.skills.length - 4}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* CARD TRIGGER BUTTONS */}
              <div className="pt-4 mt-4 border-t border-slate-50 dark:border-slate-800 grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => setActiveCandidate(cand)}
                  className="py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-center font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Voir CV Profil
                </button>
                <button
                  onClick={() => onStartChat(cand.id)}
                  className="py-1.5 rounded-lg bg-strong-50 text-strong-600 dark:bg-strong-900/20 dark:text-strong-400 hover:bg-strong-100/80 transition-colors text-center font-bold cursor-pointer"
                >
                  Contacter (Chat)
                </button>
                
                <button
                  onClick={() => setSchedulingCandidate(cand)}
                  className="col-span-2 mt-1 py-2 rounded-lg bg-strong-500 hover:bg-strong-600 text-white font-bold transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Calendar className="w-3.5 h-3.5" /> Programmer un entretien
                </button>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-12 text-center text-slate-400 text-xs">
            Aucun profil de candidat ne correspond à votre recherche.
          </div>
        )}
      </div>

      {/* MODAL 1: CANDIDATE DETAILED COMPREHENSIVE VIEW */}
      <AnimatePresence>
        {activeCandidate && (
          <div className="fixed inset-0 z-55 overflow-y-auto flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveCandidate(null)}
              className="fixed inset-0 bg-black/60 cursor-pointer"
            />
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-100 dark:border-slate-800 text-left w-full max-w-2xl relative overflow-hidden z-10 p-6 space-y-6"
            >
              {/* Close pin */}
              <button
                onClick={() => setActiveCandidate(null)}
                className="absolute top-5 right-5 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Bio details card layout */}
              <div className="flex gap-4 items-start pb-4 border-b border-slate-50 dark:border-slate-800">
                <img src={activeCandidate.photoUrl} alt={activeCandidate.fullName} className="w-16 h-16 rounded-full object-cover border" />
                <div className="space-y-1">
                  <h3 className="font-display font-extrabold text-lg text-slate-900 dark:text-white leading-tight">
                    {activeCandidate.fullName}
                  </h3>
                  <p className="text-xs font-semibold text-strong-500">
                    {activeCandidate.title}
                  </p>
                  <p className="text-[10px] text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-450" /> {activeCandidate.address}
                  </p>
                </div>
              </div>

              {/* CV Body elements */}
              <div className="space-y-4 max-h-[320px] overflow-y-auto pr-2">
                {/* Bio text */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Bio & Introduction</span>
                  <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-350">{activeCandidate.bio}</p>
                </div>

                {/* Experience blocks */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1">
                    <Briefcase className="w-3.5 h-3.5" /> Dernières Expériences
                  </span>
                  <div className="space-y-2.5">
                    {activeCandidate.experience.map((e, index) => (
                      <div key={index} className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850/50 text-xs text-left">
                        <div className="flex justify-between font-bold text-slate-800 dark:text-white">
                          <span>{e.role}</span>
                          <span className="font-normal font-mono text-slate-400 text-[10px]">{e.duration}</span>
                        </div>
                        <p className="text-strong-500 font-semibold mt-0.5 text-[11px]">{e.company}</p>
                        {e.description && <p className="text-slate-500 dark:text-slate-450 mt-2 font-normal leading-relaxed">{e.description}</p>}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Studies education list */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1">
                    <Award className="w-3.5 h-3.5" /> Diplômes & Certifications
                  </span>
                  <div className="space-y-1.5 text-xs text-left">
                    {activeCandidate.education.map((e, index) => (
                      <div key={index} className="flex justify-between items-start border-l-2 border-emerald-500 pl-2.5">
                        <div>
                          <p className="font-bold text-slate-805 dark:text-white">{e.degree}</p>
                          <p className="text-slate-500 dark:text-slate-400 text-[10px] mt-0.5">{e.school}</p>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono font-medium">{e.year}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Languages check */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Langues maîtrisées</span>
                  <div className="flex gap-4 text-xs font-semibold text-slate-600 dark:text-slate-350">
                    {activeCandidate.languages.map((l, index) => (
                      <span key={index} className="px-2 py-0.5 rounded bg-slate-50 dark:bg-slate-800 border">
                        {l.language} : <span className="font-bold text-strong-500">{l.level}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3 font-semibold text-xs">
                <button
                  onClick={() => downloadCandidateCV(activeCandidate)}
                  className="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-75 * shrink-0 flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-4 h-4" /> Exporter le Dossier (TXT)
                </button>
                <button
                  onClick={() => {
                    setActiveCandidate(null);
                    onStartChat(activeCandidate.id);
                  }}
                  className="px-4 py-2 bg-strong-500 hover:bg-strong-600 text-white rounded-lg cursor-pointer"
                >
                  Démarrer une discussion
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: INTERVIEW PROGRAMMER WITH DATE SELECT AND DYNAMIC PUSH */}
      <AnimatePresence>
        {schedulingCandidate && (
          <div className="fixed inset-0 z-55 overflow-y-auto flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setSchedulingCandidate(null)}
              className="fixed inset-0 bg-black/60 cursor-pointer"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-100 dark:border-slate-800 text-left w-full max-w-md relative overflow-hidden z-10"
            >
              {/* Header */}
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-850/50">
                <h3 className="font-display font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Calendar className="w-4.5 h-4.5 text-strong-500" />
                  Programmer un Entretien RH
                </h3>
                <button
                  onClick={() => setSchedulingCandidate(null)}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Form body */}
              <form onSubmit={handleCreateInterview} className="p-5 space-y-4">
                <div className="p-3 rounded-lg bg-strong-50 dark:bg-strong-900/20 flex gap-3 items-center">
                  <img src={schedulingCandidate.photoUrl} alt={schedulingCandidate.fullName} className="w-10 h-10 rounded-full object-cover" />
                  <div>
                    <p className="text-xs font-bold text-slate-800 dark:text-white">{schedulingCandidate.fullName}</p>
                    <p className="text-[10px] text-strong-500 font-semibold">{schedulingCandidate.title}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs text-left">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Date de l'entretien</label>
                    <input
                      type="date"
                      required
                      value={interviewDate}
                      onChange={(e) => setInterviewDate(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Heure de rendez-vous</label>
                    <input
                      type="time"
                      required
                      value={interviewTime}
                      onChange={(e) => setInterviewTime(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850 font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1 text-xs text-left">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Consignes / Descriptions</label>
                  <textarea
                    required
                    rows={3}
                    value={interviewDesc}
                    onChange={(e) => setInterviewDesc(e.target.value)}
                    className="w-full p-2.5 border rounded-lg dark:bg-slate-850"
                  />
                </div>

                {/* Submit state */}
                <div className="pt-2">
                  {schedulingSuccess ? (
                    <div className="flex items-center justify-center gap-1.5 py-2.5 rounded-lg bg-emerald-500 text-white font-bold text-xs">
                      <Check className="w-4 h-4" /> Entretien planifié et ajouté !
                    </div>
                  ) : (
                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-lg bg-strong-500 hover:bg-strong-600 text-white font-bold text-xs shadow-md cursor-pointer active:scale-95 transition-all"
                    >
                      Enregistrer dans l'agenda RH
                    </button>
                  )}
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
