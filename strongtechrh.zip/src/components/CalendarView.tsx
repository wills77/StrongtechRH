import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, Plus, Trash2, Tag, User, MapPin, X, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { CalendarEvent } from '../types';

interface CalendarViewProps {
  events: CalendarEvent[];
  onAddEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  onDeleteEvent: (eventId: string) => void;
}

export default function CalendarView({ events, onAddEvent, onDeleteEvent }: CalendarViewProps) {
  // June 2026 calendar baseline setup (1st is Monday, 30 days)
  const currentYear = 2026;
  const currentMonthIdx = 5; // June is index 5
  const monthName = 'Juin 2026';
  const daysInMonth = 30;
  const startingDayOfWeekIdx = 0; // Monday start offset (0 = Mon, 6 = Sun equivalent)

  const [selectedDay, setSelectedDay] = useState<number | null>(12); // preselect 12th of June
  const [showAddEventModal, setShowAddEventModal] = useState(false);

  // Form Fields
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'interview' | 'meeting' | 'session'>('interview');
  const [eventDate, setEventDate] = useState('2026-06-12');
  const [eventTime, setEventTime] = useState('14:30');
  const [candidateName, setCandidateName] = useState('');
  const [description, setDescription] = useState('');

  // Days list mapping
  const daysGrid = useMemo(() => {
    const grid = [];
    // padding for offsets
    for (let i = 0; i < startingDayOfWeekIdx; i++) {
      grid.push(null);
    }
    for (let day = 1; day <= daysInMonth; day++) {
      grid.push(day);
    }
    return grid;
  }, []);

  // Events of selected day helper
  const selectedDayEvents = useMemo(() => {
    if (selectedDay === null) return [];
    const formattedSelectedDate = `2026-06-${selectedDay < 10 ? '0' + selectedDay : selectedDay}`;
    return events.filter(evt => evt.date === formattedSelectedDate);
  }, [events, selectedDay]);

  // Check if a day has any events
  const dayHasEvents = (day: number) => {
    const formattedDate = `2026-06-${day < 10 ? '0' + day : day}`;
    return events.some(evt => evt.date === formattedDate);
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    onAddEvent({
      title,
      type,
      date: eventDate,
      time: eventTime,
      candidateName: candidateName || undefined,
      description
    });

    // Reset values
    setTitle('');
    setType('interview');
    setCandidateName('');
    setDescription('');
    setShowAddEventModal(false);
  };

  const getTypeBadgeStyles = (t: 'interview' | 'meeting' | 'session') => {
    switch (t) {
      case 'interview':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950/40 dark:text-purple-400 border border-purple-200/40';
      case 'meeting':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-200/40';
      case 'session':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200/40';
    }
  };

  return (
    <div className="space-y-8 text-left">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="font-display text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
            Calendrier RH
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Programmez des séances d'entretiens, réunions d'équipe ou sessions d'onboarding candidat.
          </p>
        </div>

        <button
          onClick={() => {
            if (selectedDay) {
              setEventDate(`2026-06-${selectedDay < 10 ? '0' + selectedDay : selectedDay}`);
            }
            setShowAddEventModal(true);
          }}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-strong-500 hover:bg-strong-600 text-white font-bold text-xs rounded-lg shadow-sm transition-all cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" /> Programmer un événement
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: MONTHLY GRID */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-850 p-3 rounded-lg">
            <span className="font-display font-bold text-sm text-slate-800 dark:text-white">
              {monthName}
            </span>
            <div className="flex gap-1">
              <button disabled className="p-1 rounded bg-white dark:bg-slate-800 text-slate-350 cursor-not-allowed">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button disabled className="p-1 rounded bg-white dark:bg-slate-800 text-slate-350 cursor-not-allowed">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Days labels */}
          <div className="grid grid-cols-7 gap-1 text-center font-display text-[10px] font-bold text-slate-400 uppercase tracking-wider pb-1.5 border-b border-slate-50 dark:border-slate-800">
            <span>Lun</span>
            <span>Mar</span>
            <span>Mer</span>
            <span>Jeu</span>
            <span>Ven</span>
            <span>Sam</span>
            <span>Dim</span>
          </div>

          {/* Grid dates */}
          <div className="grid grid-cols-7 gap-2">
            {daysGrid.map((day, idx) => {
              if (day === null) {
                return <div key={`empty-${idx}`} />;
              }

              const isSelected = selectedDay === day;
              const hasEvents = dayHasEvents(day);

              return (
                <button
                  key={`day-${day}`}
                  onClick={() => setSelectedDay(day)}
                  className={`aspect-square sm:p-2 flex flex-col justify-between items-center rounded-lg relative cursor-pointer font-bold text-xs font-mono transition-all border
                    ${isSelected 
                      ? 'bg-strong-500 text-white border-strong-500 shadow-md scale-105' 
                      : 'bg-slate-50 dark:bg-slate-850/40 text-slate-700 dark:text-slate-300 border-transparent hover:border-slate-200 dark:hover:border-slate-800'
                    }`}
                >
                  <span>{day}</span>
                  {hasEvents && (
                    <span className={`w-1.5 h-1.5 rounded-full absolute bottom-1 ${isSelected ? 'bg-white' : 'bg-strong-500 animate-pulse'}`} />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: EVENTS OF THE DAY */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
              <Calendar className="w-4.5 h-4.5 text-strong-500" />
              Agenda du {selectedDay ? `${selectedDay} Juin 2026` : 'Sélectionnez un jour'}
            </h3>
          </div>

          <div className="space-y-4 max-h-[360px] overflow-y-auto pr-1">
            {selectedDayEvents.length > 0 ? (
              selectedDayEvents.map((evt) => (
                <div
                  key={evt.id}
                  className="p-4 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-850/40 space-y-3.5 relative group hover:border-strong-200 dark:hover:border-strong-900/30 transition-all text-xs text-left"
                >
                  <button
                    onClick={() => onDeleteEvent(evt.id)}
                    title="Supprimer l'événement de l'agenda"
                    className="absolute top-4 right-4 p-1 rounded hover:bg-red-500/10 text-red-400 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  <div className="space-y-1.5">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide inline-block ${getTypeBadgeStyles(evt.type)}`}>
                      {evt.type === 'interview' ? 'Entretien RH' : evt.type === 'meeting' ? 'Réunion Staff' : 'Session Collective'}
                    </span>
                    <h4 className="font-display font-bold text-sm text-slate-850 dark:text-white leading-normal pr-5">
                      {evt.title}
                    </h4>
                  </div>

                  <div className="flex flex-col gap-1.5 text-slate-500 dark:text-slate-400 pt-1 font-medium">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {evt.time} (Heure de Paris)
                    </span>
                    {evt.candidateName && (
                      <span className="flex items-center gap-1.5 text-strong-550 dark:text-strong-400">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        Candidat : {evt.candidateName}
                      </span>
                    )}
                  </div>

                  <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-normal bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 p-2.5 rounded-lg text-[11px]">
                    {evt.description}
                  </p>
                </div>
              ))
            ) : (
              <div className="py-12 text-center text-slate-400 text-xs border border-dashed rounded-xl space-y-1">
                <p className="font-bold">Aucun rendez-vous planifié</p>
                <p className="text-[10px] text-slate-400/80">Créez un entretien aujourd'hui en cliquant sur le bouton ci-dessus.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SCHEDULE EVENT FORM MODAL */}
      <AnimatePresence>
        {showAddEventModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddEventModal(false)}
              className="fixed inset-0 bg-black/60 cursor-pointer"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-100 dark:border-slate-800 text-left w-full max-w-md relative overflow-hidden z-10"
            >
              {/* Header */}
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-850/50">
                <h3 className="font-display font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Calendar className="w-4.5 h-4.5 text-strong-500" />
                  Programmer un événement RH
                </h3>
                <button
                  onClick={() => setShowAddEventModal(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleCreateEvent} className="p-5 space-y-4 text-xs font-semibold">
                
                {/* Event Title */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Intitulé de l'événement</label>
                  <input
                    type="text"
                    required
                    placeholder="ex: Entretien Final Sourcing"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 text-left">
                  {/* Event Type */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Catégorie</label>
                    <select
                      value={type}
                      onChange={(e: any) => setType(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50"
                    >
                      <option value="interview">Entretien Candidat</option>
                      <option value="meeting">Réunion d'Équipe</option>
                      <option value="session">Session de Recrutement</option>
                    </select>
                  </div>

                  {/* Candidate name linked */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Candidat lié (optionnel)</label>
                    <input
                      type="text"
                      placeholder="Nom complet"
                      value={candidateName}
                      onChange={(e) => setCandidateName(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-left">
                  {/* Event Date */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Date précise</label>
                    <input
                      type="date"
                      required
                      value={eventDate}
                      onChange={(e) => setEventDate(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50"
                    />
                  </div>

                  {/* Event Time */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Heure précise</label>
                    <input
                      type="time"
                      required
                      value={eventTime}
                      onChange={(e) => setEventTime(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50 font-mono"
                    />
                  </div>
                </div>

                {/* Event Description */}
                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ordre du jour ou Consignes de l'appel</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Détaillez les questions ou liens visioconférences..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full p-2.5 border rounded-lg dark:bg-slate-850 bg-slate-50 font-normal"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setShowAddEventModal(false)}
                    className="px-4 py-2 border rounded-lg text-slate-500 cursor-pointer"
                  >
                    Fermer
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-strong-500 hover:bg-strong-600 text-white rounded-lg cursor-pointer flex items-center gap-1"
                  >
                    <Check className="w-4 h-4" /> Enregistrer dans l'agenda
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
