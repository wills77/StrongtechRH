import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { Briefcase, Users, FileCheck, Calendar, CheckSquare, Plus, ArrowUpRight, TrendingUp, UserPlus, FileText, Send } from 'lucide-react';
import { Job, CandidateProfile, Application, CalendarEvent } from '../types';

interface DashboardViewProps {
  jobs: Job[];
  candidates: CandidateProfile[];
  applications: Application[];
  events: CalendarEvent[];
  onNavigate: (tab: string) => void;
}

export default function DashboardView({ jobs, candidates, applications, events, onNavigate }: DashboardViewProps) {
  
  // Real-time dynamic KPI calculations
  const totalJobs = useMemo(() => jobs.filter(j => j.status === 'active').length, [jobs]);
  const totalCandidates = useMemo(() => candidates.length, [candidates]);
  const totalApplications = useMemo(() => applications.length, [applications]);
  
  const totalInterviews = useMemo(() => {
    return events.filter(e => e.type === 'interview').length;
  }, [events]);

  const totalAccepted = useMemo(() => {
    return applications.filter(a => a.status === 'Acceptée').length;
  }, [applications]);

  // Aggregate stats: Applications per Status
  const statusStats = useMemo(() => {
    const stats = { Reçue: 0, En_cours: 0, Entretien: 0, Acceptée: 0, Refusée: 0 };
    applications.forEach(a => {
      if (a.status === 'Reçue') stats.Reçue++;
      if (a.status === 'En cours') stats.En_cours++;
      if (a.status === 'Entretien') stats.Entretien++;
      if (a.status === 'Acceptée') stats.Acceptée++;
      if (a.status === 'Refusée') stats.Refusée++;
    });
    return stats;
  }, [applications]);

  // Aggregate stats: Jobs per City
  const cityStats = useMemo(() => {
    const counts: Record<string, number> = {};
    jobs.forEach(j => {
      counts[j.city] = (counts[j.city] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value })).slice(0, 5);
  }, [jobs]);

  return (
    <div className="space-y-8 text-left">
      
      {/* Dynamic Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="font-display text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
            Tableau de Bord RH
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Statistiques globales du cabinet StrongtechRH et pilotage consolidé de l'acquisition de talents.
          </p>
        </div>

        <button
          onClick={() => onNavigate('job-manager')}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-strong-500 hover:bg-strong-600 text-white font-bold text-xs rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" /> Nouvelle offre d'emploi
        </button>
      </div>

      {/* KPI METRIC CARDS HEADER */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
        {/* Metric 1 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-xl flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Offres Ouvertes</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white font-display">{totalJobs}</p>
          </div>
          <div className="p-3 bg-strong-50 dark:bg-strong-900/30 text-strong-500 rounded-lg">
            <Briefcase className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-xl flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Candidats</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white font-display">{totalCandidates}</p>
          </div>
          <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 rounded-lg">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-xl flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Candidatures reçues</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white font-display">{totalApplications}</p>
          </div>
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 text-blue-500 rounded-lg">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-xl flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Entretiens Planifiés</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white font-display">{totalInterviews}</p>
          </div>
          <div className="p-3 bg-purple-50 dark:bg-purple-900/20 text-purple-500 rounded-lg">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 5 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-xl flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Recrutés Finalisés</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white font-display">{totalAccepted}</p>
          </div>
          <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 rounded-lg">
            <FileCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* GRAPHIC STATS CHARTS & GRAPHS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* CHART 1: APPLICATIONS BY STATUS (BAR CHART) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-50 dark:border-slate-800">
            <h4 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-strong-500" /> Funnel d'Acquisition & Statuts Candidatures
            </h4>
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Aperçu en temps réel</span>
          </div>

          {/* SVG Custom Interactive Bar Chart */}
          <div className="space-y-4 pt-2">
            {[
              { label: 'Candidatures Reçues', count: statusStats.Reçue, color: 'bg-blue-500', pct: (statusStats.Reçue / (totalApplications || 1)) * 100 },
              { label: 'Profils en Cours', count: statusStats.En_cours, color: 'bg-amber-500', pct: (statusStats.En_cours / (totalApplications || 1)) * 100 },
              { label: 'Entretiens Planifiés', count: statusStats.Entretien, color: 'bg-purple-500', pct: (statusStats.Entretien / (totalApplications || 1)) * 100 },
              { label: 'Candidats Acceptés', count: statusStats.Acceptée, color: 'bg-emerald-500', pct: (statusStats.Acceptée / (totalApplications || 1)) * 100 },
              { label: 'Dossiers Refusés', count: statusStats.Refusée, color: 'bg-rose-500', pct: (statusStats.Refusée / (totalApplications || 1)) * 100 },
            ].map((stat, i) => (
              <div key={i} className="space-y-1.5 text-xs">
                <div className="flex justify-between font-semibold">
                  <span className="text-slate-600 dark:text-slate-400">{stat.label}</span>
                  <span className="font-mono text-slate-800 dark:text-white">
                    {stat.count} ({Math.round(stat.pct)}%)
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden relative">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.max(stat.pct, totalApplications ? 4 : 0)}%` }}
                    transition={{ delay: i * 0.1, duration: 0.8 }}
                    className={`h-full ${stat.color} rounded-full`}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CHART 2: VACANCIES BY CITY (DONUT SIMULATION) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-50 dark:border-slate-800">
            <h4 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-strong-500" /> Offres d'Emploi par Ville
            </h4>
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Répartition Géo</span>
          </div>

          <div className="flex items-center justify-center p-2">
            {/* Elegant SVG Circle Donut Graph */}
            <svg viewBox="0 0 100 100" className="w-36 h-36">
              {/* background ring */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#f1f5f9" strokeWidth="8" className="dark:stroke-slate-800" />
              
              {/* Dynamic segmented rings based on mock data distribution */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#0f4c81" strokeWidth="8" strokeDasharray="140 240" strokeDashoffset="0" />
              <circle cx="50" cy="50" r="38" fill="none" stroke="#10b981" strokeWidth="8" strokeDasharray="60 240" strokeDashoffset="-140" />
              <circle cx="50" cy="50" r="38" fill="none" stroke="#8b5cf6" strokeWidth="8" strokeDasharray="38 240" strokeDashoffset="-200" />
            </svg>
          </div>

          {/* City Stats Legend */}
          <div className="space-y-2.5 pt-1 text-xs">
            {cityStats.map((city, idx) => {
              const bgColors = ['bg-strong-500', 'bg-emerald-500', 'bg-purple-500', 'bg-amber-400', 'bg-pink-400'];
              return (
                <div key={idx} className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className={`w-3 h-3 rounded-full ${bgColors[idx % bgColors.length]}`} />
                    <span className="font-semibold text-slate-600 dark:text-slate-400 capitalize">{city.name}</span>
                  </div>
                  <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{city.value} {city.value > 1 ? 'postes' : 'poste'}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* RECENT APPLICATIONS LOGS */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex justify-between items-center pb-3 border-b border-slate-50 dark:border-slate-800">
          <h4 className="font-display font-extrabold text-sm text-slate-850 dark:text-white flex items-center gap-2">
            <UserPlus className="w-4.5 h-4.5 text-strong-500" /> Activité Récente : Candidatures Reçues
          </h4>
          <button
            onClick={() => onNavigate('candidates')}
            className="text-xs font-bold text-strong-500 hover:underline cursor-pointer flex items-center gap-0.5"
          >
            Gérer les candidats <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {applications.length > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {applications.slice(0, 5).map((app) => (
              <div key={app.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 first:pt-0 last:pb-0">
                <div className="flex items-center gap-3">
                  {/* Photo Simulation */}
                  <div className="w-9 h-9 rounded-full bg-linear-to-br from-strong-500 to-strong-700 text-white flex items-center justify-center font-display font-bold text-sm">
                    {app.candidateName.charAt(0)}
                  </div>
                  
                  <div>
                    <h5 className="text-xs font-extrabold text-slate-800 dark:text-white leading-snug">
                      {app.candidateName}
                    </h5>
                    <p className="text-[10px] text-slate-400">
                      Postule pour : <span className="font-medium text-strong-500">{app.jobTitle}</span> — {app.company}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  <span className="text-slate-400 text-[11px] font-medium">{app.dateApplied}</span>
                  <span className={`px-2.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                    app.status === 'Reçue' ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400' :
                    app.status === 'En cours' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400' :
                    app.status === 'Entretien' ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/40 dark:text-purple-400' :
                    app.status === 'Acceptée' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400' :
                    'bg-slate-100 text-slate-800'
                  }`}>
                    {app.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center text-slate-400 text-xs">
            Aucune candidature enregistrée pour le moment.
          </div>
        )}
      </div>

    </div>
  );
}
