import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Send, CheckCircle, AlertCircle, Building } from 'lucide-react';

export default function ContactView() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  // Validation states
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const tempErrors: { [key: string]: string } = {};

    // Validate inputs
    if (!name.trim()) tempErrors.name = 'Le nom complet est obligatoire.';
    if (!email.trim()) {
      tempErrors.email = 'L\'adresse email est obligatoire.';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      tempErrors.email = 'Veuillez saisir une adresse email valide.';
    }
    if (!subject.trim()) tempErrors.subject = 'Le sujet du message est obligatoire.';
    if (!message.trim()) {
      tempErrors.message = 'Le corps du message ne peut pas être vide.';
    } else if (message.trim().length < 10) {
      tempErrors.message = 'Veuillez rédiger un message de plus de 10 caractères.';
    }

    if (Object.keys(tempErrors).length > 0) {
      setErrors(tempErrors);
      return;
    }

    setErrors({});
    setSuccess(true);
    
    // Reset Form
    setTimeout(() => {
      setName('');
      setEmail('');
      setCompany('');
      setSubject('');
      setMessage('');
      setSuccess(false);
    }, 2500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
      
      {/* LEFT COLUMN: AGENCY INFORMATION DETAILS */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-6">
          <div className="space-y-1.5">
            <h3 className="font-display font-extrabold text-lg text-slate-900 dark:text-white">
              Contactez StrongtechRH
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Nos conseillers RH et experts de l'ATS répondent à vos demandes d'intégration ou partenariats sous 24h ouvrées.
            </p>
          </div>

          <div className="space-y-4 text-xs font-semibold text-slate-700 dark:text-slate-350">
            <div className="flex gap-4.5 items-start">
              <div className="p-2.5 rounded-lg bg-strong-50 dark:bg-strong-900/30 text-strong-500 border shrink-0">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <p className="text-slate-400 font-bold uppercase tracking-wider text-[9px]">Siège Social</p>
                <p className="font-normal text-slate-800 dark:text-slate-200">Tour Emeraude, 4ème étage, Boulevard d'Anfa, Casablanca</p>
                <p className="font-normal text-slate-450 text-[11px]">(Antenne européenne : Rue du Faubourg Saint-Honoré, Paris)</p>
              </div>
            </div>

            <div className="flex gap-4.5 items-start">
              <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 border shrink-0">
                <Phone className="w-4 h-4" />
              </div>
              <div className="space-y-0.5 font-mono">
                <p className="text-slate-400 font-bold uppercase tracking-wider text-[9px] font-sans">Téléphone Direct</p>
                <p className="font-bold text-slate-800 dark:text-slate-200">+212 (0) 5 22 44 88 99</p>
                <p className="font-normal text-slate-450 text-[11px] font-sans">Lundi au Vendredi : 9h00 - 18h00</p>
              </div>
            </div>

            <div className="flex gap-4.5 items-start">
              <div className="p-2.5 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-500 border shrink-0">
                <Mail className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <p className="text-slate-400 font-bold uppercase tracking-wider text-[9px]">Courriel Support</p>
                <p className="font-bold text-strong-500 hover:underline">contact@strongtechrh.com</p>
                <p className="font-normal text-slate-450 text-[11px]">Assistance technique ATS : support@strongtechrh.com</p>
              </div>
            </div>
          </div>
        </div>

        {/* Informative advice */}
        <div className="p-5 bg-linear-to-br from-strong-500/10 to-strong-700/5 rounded-xl border border-strong-100 dark:border-strong-900/20 space-y-2.5">
          <div className="flex items-center gap-2">
            <Building className="w-4.5 h-4.5 text-strong-500" />
            <span className="font-display font-black text-xs text-slate-800 dark:text-white uppercase tracking-wider">Demander une Démo Complète</span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Vous souhaitez intégrer l'ATS StrongtechRH au sein de votre corporation ou obtenir des accès Administrateurs avancés ? Précisez votre taille d'entreprise et effectifs pour un devis personnalisé.
          </p>
        </div>
      </div>

      {/* RIGHT COLUMN: VALIDATED FORM INPUTS */}
      <div className="lg:col-span-7">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs">
          <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold text-left">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Nom complet */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Nom complet *</label>
                <input
                  type="text"
                  placeholder="ex: Jean Dupont"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-strong-500 font-medium
                    ${errors.name ? 'border-red-400' : 'border-slate-200 dark:border-slate-800'}`}
                />
                {errors.name && (
                  <p className="text-[10px] text-red-500 flex items-center gap-1 font-bold mt-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {errors.name}
                  </p>
                )}
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Adresse email professionnel *</label>
                <input
                  type="text"
                  placeholder="ex: j.dupont@entreprise.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-strong-500 font-medium
                    ${errors.email ? 'border-red-400' : 'border-slate-200 dark:border-slate-800'}`}
                />
                {errors.email && (
                  <p className="text-[10px] text-red-500 flex items-center gap-1 font-bold mt-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {errors.email}
                  </p>
                )}
              </div>

              {/* Entreprise (Optionnelle) */}
              <div className="space-y-1 md:col-span-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Entreprise / Organisation (optionnel)</label>
                <input
                  type="text"
                  placeholder="ex: Strongtech Solutions Inc."
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 rounded-lg dark:bg-slate-850 bg-slate-50 font-medium"
                />
              </div>

              {/* Sujet */}
              <div className="space-y-1 md:col-span-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Sujet du message *</label>
                <input
                  type="text"
                  placeholder="ex: Demande d'informations d'intégration API"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg dark:bg-slate-850 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-strong-500 font-medium
                    ${errors.subject ? 'border-red-400' : 'border-slate-200 dark:border-slate-800'}`}
                />
                {errors.subject && (
                  <p className="text-[10px] text-red-500 flex items-center gap-1 font-bold mt-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {errors.subject}
                  </p>
                )}
              </div>

              {/* Message Description */}
              <div className="space-y-1 md:col-span-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Corps de votre demande *</label>
                <textarea
                  rows={5}
                  placeholder="Rédigez votre demande d'intégration..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className={`w-full p-3 border rounded-lg dark:bg-slate-850 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-strong-500 font-normal
                    ${errors.message ? 'border-red-400' : 'border-slate-200 dark:border-slate-800'}`}
                />
                {errors.message && (
                  <p className="text-[10px] text-red-500 flex items-center gap-1 font-bold mt-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {errors.message}
                  </p>
                )}
              </div>
            </div>

            {/* Submission Alerts */}
            <div className="pt-2">
              <AnimatePresence mode="wait">
                {success ? (
                  <motion.div
                    key="contact-success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="p-3.5 rounded-lg bg-emerald-500 text-white font-bold flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-4 h-4" /> Message envoyé avec succès !
                  </motion.div>
                ) : (
                  <button
                    type="submit"
                    className="w-full py-3 rounded-lg bg-strong-500 hover:bg-strong-600 text-white font-extrabold shadow-sm active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Envoyer ma demande
                  </button>
                )}
              </AnimatePresence>
            </div>

          </form>
        </div>
      </div>

    </div>
  );
}
