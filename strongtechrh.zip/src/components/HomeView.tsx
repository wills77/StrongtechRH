import React from 'react';
import { motion } from 'motion/react';
import { Briefcase, Users, Calendar, MessageSquare, ShieldCheck, Target, TrendingUp, Sparkles } from 'lucide-react';
import { UserRole } from '../types';

interface HomeViewProps {
  onNavigate: (tab: string) => void;
  onSetRole: (role: UserRole) => void;
  totalJobs: number;
  totalCandidates: number;
  totalApplications: number;
}

export default function HomeView({ onNavigate, onSetRole, totalJobs, totalCandidates, totalApplications }: HomeViewProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-12 md:py-20 lg:py-24">
        {/* Background decorative blobs */}
        <div className="absolute top-1/4 -left-12 w-72 h-72 bg-strong-100 dark:bg-strong-900/20 rounded-full filter blur-3xl opacity-70 -z-10" />
        <div className="absolute top-1/3 right-12 w-96 h-96 bg-emerald-100 dark:bg-emerald-950/10 rounded-full filter blur-3xl opacity-60 -z-10" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-8 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-strong-50 dark:bg-strong-900/30 text-strong-600 dark:text-strong-400 font-medium text-xs tracking-wider uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              Recrutement Intelligent & RH Augmenté
            </div>
            
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 dark:text-white leading-[1.1] tracking-tight">
              Trouvez le <span className="text-strong-500 relative inline-block">talent idéal</span> <br />
              ou décrochez votre <span className="text-emerald-500">prochain emploi</span>
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 dark:text-slate-300 max-w-xl font-normal leading-relaxed">
              La plateforme intelligente de recrutement et de gestion RH. StrongtechRH connecte les meilleurs candidats avec les recruteurs les plus exigeants grâce à des flux automatisés, un ATS intégré et un espace collaboratif fluide.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button
                id="btn-find-job-hero"
                onClick={() => {
                  onSetRole('candidate');
                  onNavigate('jobs');
                }}
                className="inline-flex items-center justify-center px-8 py-4 rounded-xl font-semibold text-white bg-strong-500 hover:bg-strong-600 shadow-lg shadow-strong-500/20 active:scale-95 transition-all text-base cursor-pointer group"
              >
                <Briefcase className="w-5 h-5 mr-2.5 transition-transform group-hover:-translate-y-0.5" />
                Trouver un emploi
              </button>
              
              <button
                id="btn-recruit-hero"
                onClick={() => {
                  onSetRole('hr');
                  onNavigate('dashboard');
                }}
                className="inline-flex items-center justify-center px-8 py-4 rounded-xl font-semibold text-slate-800 dark:text-white bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/80 shadow-md active:scale-95 transition-all text-base cursor-pointer"
              >
                Recruter maintenant
              </button>
            </div>
            
            {/* Trust badge */}
            <div className="pt-4 flex flex-wrap gap-x-6 gap-y-2 items-center text-xs text-slate-400">
              <span className="font-semibold uppercase tracking-wider text-[10px] text-slate-500">Partenaire clé de l'emploi :</span>
              <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-strong-500" /> RGPD Compliant</span>
              <span className="flex items-center gap-1"><Target className="w-4 h-4 text-emerald-500" /> ATS Intégré</span>
              <span className="flex items-center gap-1"><TrendingUp className="w-4 h-4 text-purple-500" /> 100% Digitalisé</span>
            </div>
          </div>

          {/* Graphic Side */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-[420px] lg:max-w-none">
              {/* Outer decorative ring */}
              <div className="absolute -inset-1.5 rounded-3xl bg-linear-to-r from-strong-500 to-emerald-400 opacity-20 blur-xl animate-pulse" />
              
              <div className="relative bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-2xl border border-slate-100 dark:border-slate-800">
                {/* Visual ATS Mockup Card */}
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-strong-500 text-white flex items-center justify-center font-display font-bold">ST</div>
                    <div>
                      <h4 className="font-display font-bold text-sm text-slate-800 dark:text-white">Aperçu RH Dashboard</h4>
                      <p className="text-[11px] text-slate-400">Suivi temps réel</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 animate-pulse">● En Ligne</span>
                </div>

                <div className="space-y-3.5">
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center border border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-md bg-strong-50 dark:bg-strong-900/40 text-strong-600 dark:text-strong-400">
                        <Users className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Candidats Qualifiés</span>
                    </div>
                    <span className="font-display font-bold text-sm text-strong-600 dark:text-strong-400">+{totalCandidates} Actifs</span>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center border border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-md bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400">
                        <Briefcase className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Offres Ouvertes</span>
                    </div>
                    <span className="font-display font-bold text-sm text-emerald-600 dark:text-emerald-500">{totalJobs} Postes</span>
                  </div>

                  {/* Tiny Job Alert mockup */}
                  <div className="p-3 rounded-xl border border-slate-200/60 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-xs relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-16 h-16 bg-strong-500/5 rounded-full -mr-4 -mt-4" />
                    <div className="flex gap-2.5">
                      <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=70" alt="Candidat" className="w-8 h-8 rounded-full object-cover" />
                      <div className="text-left text-xs">
                        <p className="font-bold text-slate-800 dark:text-white">Amine E.</p>
                        <p className="text-[10px] text-slate-400">Postule pour : <span className="font-medium text-strong-500">UI/UX Designer</span></p>
                        <div className="mt-1.5 flex gap-1">
                          <span className="px-1.5 py-0.5 rounded bg-linear-to-r from-blue-500/10 to-teal-500/10 text-strong-500 text-[8px] font-bold">Figma</span>
                          <span className="px-1.5 py-0.5 rounded bg-linear-to-r from-blue-500/10 to-teal-500/10 text-strong-500 text-[8px] font-bold font-mono">Expert</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Cards Section */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 rounded-2xl p-8 shadow-sm">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="p-4 border-r border-slate-100 last:border-0 dark:border-slate-800">
            <p className="text-4xl font-extrabold text-strong-500 font-display">{totalJobs}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-semibold">Offres d'Emploi Actives</p>
          </div>
          <div className="p-4 border-r border-slate-100 last:border-0 dark:border-slate-800">
            <p className="text-4xl font-extrabold text-emerald-500 font-display">{totalCandidates}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-semibold">Profils Qualifiés</p>
          </div>
          <div className="p-4 border-r border-slate-100 last:border-0 dark:border-slate-800">
            <p className="text-4xl font-extrabold text-blue-500 font-display">{totalApplications}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-semibold">Candidatures Gérées</p>
          </div>
          <div className="p-4">
            <p className="text-4xl font-extrabold text-purple-500 font-display">98%</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-semibold">Taux de Satisfaction</p>
          </div>
        </div>
      </section>

      {/* Feature Details section */}
      <section className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <h2 className="font-display text-3xl font-extrabold text-slate-900 dark:text-white">
            Pourquoi choisir StrongtechRH ?
          </h2>
          <p className="text-slate-500 dark:text-slate-400">
            Une expérience unifiée et enrichie pensée pour les professionnels RH et les talents modernes.
          </p>
        </div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {/* Card 1 */}
          <motion.div variants={itemVariants} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-strong-50 dark:bg-strong-950/50 text-strong-500 flex items-center justify-center mb-5 border border-strong-100 dark:border-strong-900/30">
              <Briefcase className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2 leading-snug">
              Gestion Intelligente des Offres
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Publiez, éditez et archivez vos offres d'emploi en quelques clics. Utilisez nos filtres avancés pour trier les candidatures.
            </p>
          </motion.div>

          {/* Card 2 */}
          <motion.div variants={itemVariants} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-500 flex items-center justify-center mb-5 border border-emerald-100 dark:border-emerald-900/30">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2 leading-snug">
              Suivi Candidat Transparent
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Modifiez votre profil candidat, déposez votre CV, et suivez le statut de chacune de vos candidatures grâce à des badges colorés.
            </p>
          </motion.div>

          {/* Card 3 */}
          <motion.div variants={itemVariants} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-purple-50 dark:bg-purple-950/50 text-purple-500 flex items-center justify-center mb-5 border border-purple-100 dark:border-purple-900/30">
              <Calendar className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2 leading-snug">
              Calendrier Partagé & Planification
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Programmez et visualisez vos sessions d'entretiens, réunions d'équipes et comités de recrutement directement sur un calendrier interactif.
            </p>
          </motion.div>

          {/* Card 4 */}
          <motion.div variants={itemVariants} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-500 flex items-center justify-center mb-5 border border-blue-100 dark:border-blue-900/30">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2 leading-snug">
              Messagerie Interne Directe
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Facilitez l'échange direct entre recruteurs et candidats. Un historique instantané et sécurisé évite les va-et-vient d'emails fastidieux.
            </p>
          </motion.div>

          {/* Card 5 */}
          <motion.div variants={itemVariants} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-500 flex items-center justify-center mb-5 border border-amber-100 dark:border-amber-900/30">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2 leading-snug">
              Dashboard Statistiques Premium
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Un tableau de bord complet avec des indicateurs clés et des analyses graphiques interactives pour monitorer vos KPI de recrutement.
            </p>
          </motion.div>

          {/* Card 6 */}
          <motion.div variants={itemVariants} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-lg bg-pink-50 dark:bg-pink-950/50 text-pink-500 flex items-center justify-center mb-5 border border-pink-100 dark:border-pink-900/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2 leading-snug">
              Haute Conformité & Protection
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Gestion rigoureuse du dépôt de curriculum vitæ et données candidat pour garantir la sécurité et la conformité légale de votre recrutement.
            </p>
          </motion.div>
        </motion.div>
      </section>

      {/* Modern Banner CTA */}
      <section className="bg-linear-to-r from-strong-600 to-strong-800 text-white rounded-2xl p-8 md:p-12 shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-16 -mt-16" />
        <div className="max-w-xl text-left space-y-4">
          <h3 className="font-display text-2xl md:text-3xl font-extrabold">Rejoignez l'ère du recrutement unifié</h3>
          <p className="text-strong-100 text-sm md:text-base">
            Créez un profil de candidat gratuit pour postuler aux 20 postes disponibles, ou activez l'espace recruteur pour lancer vos campagnes de sourcing et piloter vos futurs entretiens.
          </p>
          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => {
                onSetRole('candidate');
                onNavigate('jobs');
              }}
              className="px-5 py-2.5 rounded-lg bg-white text-strong-600 font-semibold text-sm hover:bg-slate-50 shadow-xs active:scale-95 transition-all cursor-pointer"
            >
              Parcourir les Offres
            </button>
            <button
              onClick={() => {
                onSetRole('hr');
                onNavigate('dashboard');
              }}
              className="px-5 py-2.5 rounded-lg bg-strong-700/60 text-white font-semibold text-sm border border-white/20 hover:bg-strong-700/80 active:scale-95 transition-all cursor-pointer"
            >
              Démo Recruteur (RH)
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
