import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Briefcase, Search, Plus, Trash2, Edit2, Archive, CheckCircle, RefreshCcw, MapPin, DollarSign, X, Check } from 'lucide-react';
import { Job } from '../types';

interface JobManagerViewProps {
  jobs: Job[];
  onAddJob: (job: Omit<Job, 'id' | 'publishedDate'>) => void;
  onUpdateJob: (job: Job) => void;
  onDeleteJob: (jobId: string) => void;
}

export default function JobManagerView({ jobs, onAddJob, onUpdateJob, onDeleteJob }: JobManagerViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal controllers
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('Strongtech Solutions');
  const [city, setCity] = useState('');
  const [contractType, setContractType] = useState<'CDI' | 'CDD' | 'Stage' | 'Freelance' | 'Alternance'>('CDI');
  const [telework, setTelework] = useState(false);
  const [salaryMin, setSalaryMin] = useState(30000);
  const [salaryMax, setSalaryMax] = useState(60000);
  const [experienceLevel, setExperienceLevel] = useState<'Junior' | 'Intermédiaire' | 'Senior' | 'Expert'>('Junior');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [tagsInput, setTagsInput] = useState('');

  // Search filter
  const filteredJobs = jobs.filter(job => 
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openAddModal = () => {
    setEditingJob(null);
    setTitle('');
    setCompany('Strongtech Solutions');
    setCity('');
    setContractType('CDI');
    setTelework(false);
    setSalaryMin(35000);
    setSalaryMax(65000);
    setExperienceLevel('Junior');
    setShortDescription('');
    setDescription('');
    setTagsInput('');
    setShowFormModal(true);
  };

  const openEditModal = (job: Job) => {
    setEditingJob(job);
    setTitle(job.title);
    setCompany(job.company);
    setCity(job.city);
    setContractType(job.contractType);
    setTelework(job.telework);
    setSalaryMin(job.salaryMin);
    setSalaryMax(job.salaryMax);
    setExperienceLevel(job.experienceLevel);
    setShortDescription(job.shortDescription);
    setDescription(job.description);
    setTagsInput(job.requirements.join(', '));
    setShowFormModal(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const requirements = tagsInput.split(',').map(tag => tag.trim()).filter(tag => tag !== '');

    if (editingJob) {
      // Update
      onUpdateJob({
        ...editingJob,
        title,
        company,
        city,
        contractType,
        telework,
        salaryMin,
        salaryMax,
        experienceLevel,
        shortDescription,
        description,
        requirements
      });
    } else {
      // Add
      onAddJob({
        title,
        company,
        city,
        contractType,
        telework,
        salaryMin,
        salaryMax,
        experienceLevel,
        shortDescription,
        description,
        requirements,
        status: 'active'
      });
    }

    setShowFormModal(false);
  };

  const handleToggleArchive = (job: Job) => {
    onUpdateJob({
      ...job,
      status: job.status === 'active' ? 'archived' : 'active'
    });
  };

  return (
    <div className="space-y-8 text-left">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="font-display text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
            Gestion du Catalogue d'Offres
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Créez, modifiez, archivez ou supprimez les fiches d'emploi publiées sur le portail StrongtechRH.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-strong-500 hover:bg-strong-600 text-white font-bold text-xs rounded-lg shadow-sm transition-all cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" /> Publier une offre
        </button>
      </div>

      {/* SEARCH AND FILTER FIELD */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Rechercher par poste, entreprise, ou ville..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-strong-500 text-sm"
          />
        </div>
      </div>

      {/* JOBS TABLE CATALOG */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850/40 text-slate-400 font-bold uppercase tracking-wider">
                <th className="py-4 px-5">Titre du poste</th>
                <th className="py-4 px-5">Ville & Type</th>
                <th className="py-4 px-5">Salaire annuel</th>
                <th className="py-4 px-5">Niveau</th>
                <th className="py-4 px-5 text-center">Statut recrue</th>
                <th className="py-4 px-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredJobs.length > 0 ? (
                filteredJobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-850/10 transition-colors">
                    <td className="py-4 px-5">
                      <div className="font-bold text-slate-800 dark:text-slate-100">{job.title}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{job.company}</div>
                    </td>
                    <td className="py-4 px-5">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span className="font-semibold text-slate-600 dark:text-slate-350">{job.city}</span>
                      </div>
                      <span className="inline-block mt-1 font-mono text-[9px] font-extrabold text-strong-500 bg-strong-500/10 px-1.5 py-0.5 rounded uppercase">
                        {job.contractType}
                      </span>
                    </td>
                    <td className="py-4 px-5 font-mono font-bold text-slate-700 dark:text-slate-300">
                      {job.salaryMin.toLocaleString()} - {job.salaryMax.toLocaleString()} €
                    </td>
                    <td className="py-4 px-5">
                      <span className="font-medium text-slate-500 dark:text-slate-400">
                        {job.experienceLevel}
                      </span>
                    </td>
                    <td className="py-4 px-5 text-center">
                      <span className={`inline-block px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-wide rounded-full border ${
                        job.status === 'active' 
                          ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/10' 
                          : 'bg-slate-100 text-slate-500 border-slate-200 dark:bg-slate-800 dark:border-slate-700'
                      }`}>
                        {job.status === 'active' ? 'Affiché' : 'Archivé'}
                      </span>
                    </td>
                    <td className="py-4 px-5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Archive Toggle btn */}
                        <button
                          onClick={() => handleToggleArchive(job)}
                          title={job.status === 'active' ? 'Archiver' : 'Activer'}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors cursor-pointer"
                        >
                          <Archive className="w-4 h-4" />
                        </button>
                        
                        {/* Edit Btn */}
                        <button
                          onClick={() => openEditModal(job)}
                          title="Modifier"
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-405 hover:text-strong-500 dark:hover:text-strong-400 transition-colors cursor-pointer"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        {/* Delete Btn */}
                        <button
                          onClick={() => {
                            if (confirm('Voulez-vous vraiment supprimer définitivement cette offre ?')) {
                              onDeleteJob(job.id);
                            }
                          }}
                          title="Supprimer"
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-red-500/10 hover:text-red-500 text-slate-400 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 text-xs">
                    Aucune offre d'emploi ne correspond à votre recherche.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* JOBS MODAL FORM (ADD / EDIT) */}
      <AnimatePresence>
        {showFormModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFormModal(false)}
              className="fixed inset-0 bg-black/60 cursor-pointer"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-100 dark:border-slate-800 max-w-2xl w-full relative overflow-hidden text-left z-10"
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-850/50">
                <h3 className="font-display font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Briefcase className="w-4.5 h-4.5 text-strong-500" />
                  {editingJob ? "Modifier la fiche de poste" : "Créer et publier une offre"}
                </h3>
                <button
                  onClick={() => setShowFormModal(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Form */}
              <form onSubmit={handleFormSubmit} className="p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Job Title */}
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Intitulé officiel du poste</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Architecte d'Infrastructures Cloud Kubernetes"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    />
                  </div>

                  {/* City */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ville / Localisation</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Paris, Lyon, Casablanca"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    />
                  </div>

                  {/* Company */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Nom de la société d'accueil</label>
                    <input
                      type="text"
                      required
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    />
                  </div>

                  {/* Contract Type */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Type de contrat proposé</label>
                    <select
                      value={contractType}
                      onChange={(e: any) => setContractType(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    >
                      <option value="CDI">CDI</option>
                      <option value="CDD">CDD</option>
                      <option value="Stage">Stage</option>
                      <option value="Freelance">Freelance</option>
                      <option value="Alternance">Alternance</option>
                    </select>
                  </div>

                  {/* Experience Level */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Séniorité exigée</label>
                    <select
                      value={experienceLevel}
                      onChange={(e: any) => setExperienceLevel(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    >
                      <option value="Junior">Junior (Débutant)</option>
                      <option value="Intermédiaire">Intermédiaire (2-5 ans)</option>
                      <option value="Senior">Senior (5-8 ans)</option>
                      <option value="Expert">Expert (&gt; 8 ans)</option>
                    </select>
                  </div>

                  {/* Min Salary */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fourchette salaire minimal (€/an)</label>
                    <input
                      type="number"
                      required
                      value={salaryMin}
                      onChange={(e) => setSalaryMin(parseInt(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white font-mono"
                    />
                  </div>

                  {/* Max Salary */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fourchette salaire maximal (€/an)</label>
                    <input
                      type="number"
                      required
                      value={salaryMax}
                      onChange={(e) => setSalaryMax(parseInt(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white font-mono"
                    />
                  </div>

                  {/* Telework Check */}
                  <div className="md:col-span-2 flex items-center gap-3 py-1">
                    <input
                      id="form-telework"
                      type="checkbox"
                      checked={telework}
                      onChange={(e) => setTelework(e.target.checked)}
                      className="w-4 h-4 text-strong-500 rounded border-slate-200 dark:border-slate-800 focus:ring-strong-500 accent-strong-500"
                    />
                    <label htmlFor="form-telework" className="text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer">
                      Télétravail à distance autorisé régulièrement / total
                    </label>
                  </div>

                  {/* Short Description */}
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Accroche / Description courte (pour listes)</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Pilotez l'architecture et configurez les pipelines CI/CD..."
                      value={shortDescription}
                      onChange={(e) => setShortDescription(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    />
                  </div>

                  {/* Requirements / Tags */}
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tags technologies & compétences (séparés par virgules)</label>
                    <input
                      type="text"
                      placeholder="ex: React.js, TypeScript, Next.js, Kubernetes"
                      value={tagsInput}
                      onChange={(e) => setTagsInput(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    />
                  </div>

                  {/* Long Description */}
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Mission complète & Profil recherché</label>
                    <textarea
                      required
                      rows={5}
                      placeholder="..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full p-3 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white"
                    />
                  </div>
                </div>

                {/* Submit trigger */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowFormModal(false)}
                    className="px-4 py-2 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 text-xs font-semibold rounded-lg cursor-pointer transition-colors"
                  >
                    Fermer
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-strong-500 hover:bg-strong-600 text-white text-xs font-extrabold rounded-lg shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    {editingJob ? 'Sauvegarder les modifications' : 'Publier immédiatement'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
