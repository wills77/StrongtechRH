import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Send, User, Sparkles, CheckCheck, Loader2 } from 'lucide-react';
import { ChatSession, ChatMessage, UserRole } from '../types';

interface MessagesViewProps {
  chatSessions: ChatSession[];
  activeSessionId: string | null;
  role: UserRole;
  onSendMessage: (sessionId: string, text: string, senderId: 'candidate' | 'hr') => void;
  onSetActiveSession: (sessionId: string | null) => void;
  onMarkRead: (sessionId: string) => void;
}

export default function MessagesView({ 
  chatSessions, 
  activeSessionId, 
  role, 
  onSendMessage, 
  onSetActiveSession,
  onMarkRead 
}: MessagesViewProps) {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Filter based on selected role
  // HR/Admin sees all chats, Candidate sees only their own (e.g. 'chat-1' representing Yassine Belkacem's chat)
  const accessibleSessions = useMemo(() => {
    if (role === 'candidate') {
      return chatSessions.filter(c => c.candidateId === 'cand-user');
    }
    return chatSessions;
  }, [chatSessions, role]);

  // Set default active session if not selected
  useEffect(() => {
    if (accessibleSessions.length > 0 && !activeSessionId) {
      onSetActiveSession(accessibleSessions[0].id);
      onMarkRead(accessibleSessions[0].id);
    }
  }, [accessibleSessions, activeSessionId, onSetActiveSession, onMarkRead]);

  // Find active session
  const activeSession = useMemo(() => {
    return chatSessions.find(s => s.id === activeSessionId) || null;
  }, [chatSessions, activeSessionId]);

  // Auto Scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeSession?.messages, isTyping]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeSession) return;

    const senderId = role === 'candidate' ? 'candidate' : 'hr';
    onSendMessage(activeSession.id, inputText.trim(), senderId);
    setInputText('');

    // If sent by HR, trigger a smart mock response from the candidate!
    if (role !== 'candidate') {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        const replies = [
          "Entendu ! J'ai bien noté les consignes. Je me prépare pour notre échange.",
          "C'est parfait pour moi, l'agenda est mis à jour de mon côté également.",
          "Merci pour votre réactivité ! J'ai hâte de discuter de l'évaluation technologique.",
          "Pouvez-vous me confirmer s'il s'agit d'un appel visio ou audio classique ?",
          "Pas de soucis. Je regarderai plus en détail le document de test."
        ];
        const randomReply = replies[Math.floor(Math.random() * replies.length)];
        onSendMessage(activeSession.id, randomReply, 'candidate');
      }, 1800);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl shadow-xs grid grid-cols-1 md:grid-cols-12 h-[560px] overflow-hidden text-left">
      
      {/* SIDEBAR: CHAT INSTANCES */}
      <div className="md:col-span-4 border-r border-slate-100 dark:border-slate-800 flex flex-col h-full bg-slate-50/40 dark:bg-slate-850/10">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="font-display font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
            <MessageSquare className="w-4.5 h-4.5 text-strong-500" /> Discussion interne
          </h3>
          <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">
            {role === 'candidate' ? 'Mon conseiller RH' : 'Candidats à contacter'}
          </p>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {accessibleSessions.length > 0 ? (
            accessibleSessions.map((session) => {
              const isActive = session.id === activeSessionId;
              const hasUnread = session.unread && role !== 'candidate'; // assume unread is for HR

              return (
                <button
                  key={session.id}
                  onClick={() => {
                    onSetActiveSession(session.id);
                    onMarkRead(session.id);
                  }}
                  className={`w-full p-4 flex gap-3 text-left transition-colors relative cursor-pointer
                    ${isActive 
                      ? 'bg-strong-500/10 dark:bg-strong-500/15 border-l-4 border-strong-500' 
                      : 'hover:bg-slate-50 dark:hover:bg-slate-850/10'
                    }`}
                >
                  <img
                    src={role === 'candidate' 
                      ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150' // HR representative icon
                      : session.candidatePhotoUrl
                    }
                    alt="avatar"
                    className="w-10 h-10 rounded-full object-cover shrink-0 border"
                  />

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex justify-between items-start">
                      <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {role === 'candidate' ? 'Cabinet Conseil RH Strongtech' : session.candidateName}
                      </p>
                      <span className="text-[9px] text-slate-400 font-mono shrink-0">{session.lastUpdated}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 truncate font-semibold">
                      {role === 'candidate' ? 'ATS Suivi de Dossier' : session.candidateTitle}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate font-normal leading-normal">
                      {session.lastMessage}
                    </p>
                  </div>

                  {/* Red Dot unread tracker */}
                  {hasUnread && (
                    <span className="absolute right-4 bottom-4 w-2.5 h-2.5 rounded-full bg-strong-500 animate-pulse" />
                  )}
                </button>
              );
            })
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs">
              Aucune conversation de recrutement disponible.
            </div>
          )}
        </div>
      </div>

      {/* CHAT WINDOW STREAM */}
      <div className="md:col-span-8 flex flex-col h-full bg-slate-50/10 dark:bg-slate-900/10">
        {activeSession ? (
          <>
            {/* Header detail */}
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900">
              <div className="flex items-center gap-3">
                <img
                  src={role === 'candidate' 
                    ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150' 
                    : activeSession.candidatePhotoUrl
                  }
                  alt="Avatar active"
                  className="w-9 h-9 rounded-full object-cover border"
                />
                <div>
                  <h4 className="text-xs font-extrabold text-slate-900 dark:text-white leading-snug">
                    {role === 'candidate' ? 'Responsable Recrutement Strongtech' : activeSession.candidateName}
                  </h4>
                  <p className="text-[10px] text-slate-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" /> Actif sur la plateforme (ATS)
                  </p>
                </div>
              </div>

              {role !== 'candidate' && (
                <span className="text-[10px] bg-strong-500/10 text-strong-500 font-mono py-0.5 px-2.5 rounded border border-strong-500/10">
                  {activeSession.candidateTitle}
                </span>
              )}
            </div>

            {/* Chats stream list */}
            <div 
              ref={scrollRef} 
              className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/30 dark:bg-slate-950/20"
            >
              {activeSession.messages.map((m) => {
                // Determine if this message is of the current player/role
                // HR's message is sent by 'hr'
                // Candidate's message is sent by 'candidate'
                const isMyMessage = (role === 'candidate' && m.senderId === 'candidate') || 
                                    (role !== 'candidate' && m.senderId === 'hr');

                return (
                  <div
                    key={m.id}
                    className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'} text-xs font-normal relative`}
                  >
                    <div className="max-w-[75%] space-y-1">
                      <div className={`p-3.5 rounded-2xl leading-normal text-left
                        ${isMyMessage 
                          ? 'bg-strong-500 text-white rounded-br-none shadow-sm' 
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-100 rounded-bl-none border border-slate-100 dark:border-slate-700/60'
                        }`}
                      >
                        <p>{m.text}</p>
                      </div>

                      <div className={`flex items-center gap-1.5 text-[9px] text-slate-400 font-mono mr-1 ml-1 ${isMyMessage ? 'justify-end' : 'justify-start'}`}>
                        <span>{m.timestamp}</span>
                        {isMyMessage && <CheckCheck className="w-3.5 h-3.5 text-blue-400" />}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Dynamic simulated typing indicator */}
              <AnimatePresence>
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="flex justify-start text-[11px] text-slate-400 items-center gap-1.5"
                  >
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-strong-500" />
                    <span>Le candidat est en train d'écrire...</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Form actions */}
            <form onSubmit={handleSend} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-2">
              <input
                type="text"
                placeholder={role === 'candidate' ? 'Écrire un message à l\'équipe RH...' : "Écrire un message à ce candidat... (Sélectionnez Entrée)"}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-strong-500 text-xs font-normal"
              />
              <button
                type="submit"
                className="p-2.5 rounded-xl bg-strong-500 hover:bg-strong-600 text-white shadow-xs cursor-pointer active:scale-95 transition-all flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-400 space-y-3">
            <MessageSquare className="w-12 h-12 text-slate-300" />
            <p className="text-xs">Sélectionnez une discussion dans la colonne de gauche pour démarrer.</p>
          </div>
        )}
      </div>

    </div>
  );
}
