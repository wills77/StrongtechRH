export type UserRole = 'candidate' | 'hr' | 'admin';

export interface Job {
  id: string;
  title: string;
  company: string;
  city: string;
  contractType: 'CDI' | 'CDD' | 'Stage' | 'Freelance' | 'Alternance';
  telework: boolean;
  salaryMin: number;
  salaryMax: number;
  publishedDate: string;
  experienceLevel: 'Junior' | 'Intermédiaire' | 'Senior' | 'Expert';
  description: string;
  shortDescription: string;
  requirements: string[]; // List of skills / requirements
  status: 'active' | 'archived';
}

export interface CandidateProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  address: string;
  photoUrl: string;
  title: string;
  seniority: 'Junior' | 'Intermédiaire' | 'Senior' | 'Expert';
  bio: string;
  skills: string[];
  education: {
    degree: string;
    school: string;
    year: string;
  }[];
  experience: {
    role: string;
    company: string;
    duration: string;
    description: string;
  }[];
  languages: {
    language: string;
    level: string;
  }[];
  cvFileName?: string;
}

export type ApplicationStatus = 'Reçue' | 'En cours' | 'Entretien' | 'Acceptée' | 'Refusée';

export interface Application {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  dateApplied: string;
  status: ApplicationStatus;
  coverLetter?: string;
  cvFileName: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  type: 'interview' | 'meeting' | 'session';
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  candidateName?: string;
  description: string;
}

export interface Notification {
  id: string;
  title: string;
  description: string;
  date: string;
  read: boolean;
  type: 'application' | 'interview' | 'job_expired' | 'new_candidate';
}

export interface ChatMessage {
  id: string;
  senderId: 'candidate' | 'hr';
  senderName: string;
  text: string;
  timestamp: string;
}

export interface ChatSession {
  id: string;
  candidateId: string;
  candidateName: string;
  candidatePhotoUrl: string;
  candidateTitle: string;
  lastMessage: string;
  lastUpdated: string;
  unread: boolean;
  messages: ChatMessage[];
}
