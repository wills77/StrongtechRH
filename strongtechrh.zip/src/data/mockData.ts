import { Job, CandidateProfile, Application, CalendarEvent, Notification, ChatSession } from '../types';

export const initialJobs: Job[] = [
  {
    id: 'job-1',
    title: 'Développeur Full Stack Senior React & Node.js',
    company: 'Strongtech Solutions',
    city: 'Paris',
    contractType: 'CDI',
    telework: true,
    salaryMin: 55000,
    salaryMax: 70000,
    publishedDate: '2026-06-05',
    experienceLevel: 'Senior',
    shortDescription: 'Rejoignez notre équipe agile pour concevoir, développer et optimiser nos applications web à fort trafic.',
    description: 'En tant que Développeur Full Stack Senior, vous interviendrez sur l\'ensemble du cycle de vie de nos produits SaaS. Vous participerez activement à la conception de l\'architecture logicielle, au développement de nouvelles fonctionnalités avec React et Node.js, et ferez rayonner les bonnes pratiques de développement (TDD, clean code, CI/CD). Vous accompagnerez également les développeurs juniors.',
    requirements: ['React.js', 'Node.js', 'TypeScript', 'PostgreSQL', 'Docker', 'GraphQL'],
    status: 'active'
  },
  {
    id: 'job-2',
    title: 'Chef de Projet RH & Recrutement',
    company: 'Innovate Group',
    city: 'Lyon',
    contractType: 'CDI',
    telework: false,
    salaryMin: 42000,
    salaryMax: 50000,
    publishedDate: '2026-06-08',
    experienceLevel: 'Intermédiaire',
    shortDescription: 'Pilotez l\'acquisition de talents et l\'intégration des collaborateurs pour accompagner notre croissance rapide.',
    description: 'Sous la responsabilité du Directeur des Ressources Humaines, vous gérerez l\'ensemble du processus de recrutement, de la définition du besoin avec les managers jusqu\'à l\'onboarding du candidat. Vous serez également force de proposition pour l\'amélioration de notre marque employeur et l\'organisation de sessions de team building.',
    requirements: ['Recrutement IT', 'Sourcing', 'Gestion de projet', 'Marque Employeur', 'ATS'],
    status: 'active'
  },
  {
    id: 'job-3',
    title: 'Consultant Cloud DevOps AWS',
    company: 'Skyward Cloud Services',
    city: 'Bordeaux',
    contractType: 'Freelance',
    telework: true,
    salaryMin: 85000, // equivalent calculated billing
    salaryMax: 105000,
    publishedDate: '2026-06-07',
    experienceLevel: 'Expert',
    shortDescription: 'Accompagnez nos clients grands comptes dans leur migration Cloud et l\'automatisation de leurs infrastructures.',
    description: 'Nous recherchons un consultant AWS DevOps pour mener à bien des missions d\'architecture et de déploiement d\'infrastructures de cloud hybrides. Vous serez responsable de la conteneurisation des services, du déploiement de pipelines CI/CD robustes avec GitLab CI, et de la mise en place du monitoring proactif.',
    requirements: ['AWS', 'Kubernetes', 'Terraform', 'CI/CD', 'Ansible', 'Python'],
    status: 'active'
  },
  {
    id: 'job-4',
    title: 'UX/UI Designer Talentueux',
    company: 'Pixel Engine',
    city: 'Nantes',
    contractType: 'CDD',
    telework: true,
    salaryMin: 35000,
    salaryMax: 45000,
    publishedDate: '2026-06-04',
    experienceLevel: 'Intermédiaire',
    shortDescription: 'Concevez des expériences utilisateur simples et mémorables pour nos plateformes web et applications mobiles.',
    description: 'Intégré au sein du pôle Produit, vous travaillerez en étroite collaboration avec les Product Managers et les développeurs frontend. Votre mission consistera à effectuer de la recherche utilisateur, formaliser des parcours (wireframes), créer des prototypes interactifs haute fidélité avec Figma, et maintenir notre Design System à jour.',
    requirements: ['Figma', 'User Research', 'Wireframing', 'Prototypage', 'Design System', 'Adobe CC'],
    status: 'active'
  },
  {
    id: 'job-5',
    title: 'Développeur Frontend Junior Reach / Vue.js',
    company: 'Avenir Digital',
    city: 'Marseille',
    contractType: 'Alternance',
    telework: true,
    salaryMin: 18000,
    salaryMax: 24000,
    publishedDate: '2026-06-09',
    experienceLevel: 'Junior',
    shortDescription: 'Formez-vous aux meilleures technos web au sein d\'une équipe de passionnés de la tech.',
    description: 'Dans le cadre de votre formation en alternance, vous rejoindrez notre équipe frontend. Accompagné d\'un tuteur senior, vous participerez à l\'intégration de maquettes responsives, à l\'écriture de composants réutilisables en React/Vue et à la correction de bugs. Une opportunité unique de progresser rapidement !',
    requirements: ['HTML5 / CSS3', 'JavaScript', 'React.js', 'Tailwind CSS', 'Git'],
    status: 'active'
  },
  {
    id: 'job-6',
    title: 'Auditeur Financier Junior',
    company: 'Global Audit Partners',
    city: 'Paris',
    contractType: 'CDI',
    telework: false,
    salaryMin: 38000,
    salaryMax: 44000,
    publishedDate: '2026-06-02',
    experienceLevel: 'Junior',
    shortDescription: 'Débutez votre carrière en audit au sein d\'un cabinet de renommée internationale, axé sur l\'humain.',
    description: 'Au sein de notre équipe Audit Financier, vous participerez à des missions de commissariat aux comptes pour des clients de secteurs variés (industrie, retail, tech). Vous mènerez des revues de contrôle interne, vérifierez la conformité des états financiers, et rédigerez des notes de synthèse.',
    requirements: ['Comptabilité', 'Normes IFRS', 'Excel', 'Analyse Financière', 'Rigueur'],
    status: 'active'
  },
  {
    id: 'job-7',
    title: 'Data Analyst & Business Intelligence Specialist',
    company: 'Metrics & Co',
    city: 'Toulouse',
    contractType: 'CDI',
    telework: true,
    salaryMin: 45000,
    salaryMax: 55000,
    publishedDate: '2026-06-06',
    experienceLevel: 'Intermédiaire',
    shortDescription: 'Transformez nos volumes de données en insights stratégiques exploitables pour les équipes métiers.',
    description: 'Votre mission sera d\'extraire, de nettoyer et d\'analyser les données issues de nos différents outils. Vous concevrez des dashboards dynamiques et interactifs sur Tableau ou Power BI pour suivre les indicateurs clés de performance (KPI) et faciliterez la prise de décision pour la direction.',
    requirements: ['SQL', 'Tableau', 'Power BI', 'Python', 'Google Analytics', 'A/B Testing'],
    status: 'active'
  },
  {
    id: 'job-8',
    title: 'Product Owner SAAS B2B',
    company: 'Synergy Corp',
    city: 'Montpellier',
    contractType: 'CDI',
    telework: true,
    salaryMin: 50000,
    salaryMax: 62000,
    publishedDate: '2026-06-06',
    experienceLevel: 'Senior',
    shortDescription: 'Portez la vision produit et pilotez la roadmap d\'un de nos modules les plus stratégiques.',
    description: 'En lien direct avec le Head of Product, vous rédigerez les User Stories, définirez le Product Backlog, et gérerez les sprints d\'une équipe de 5 développeurs. Vous animerez les rituels Scrum et serez en dialogue constant avec les clients pour comprendre leurs irritants.',
    requirements: ['Scrum', 'Product Backlog', 'Jira', 'Analyses concurrentielles', 'Story Mapping'],
    status: 'active'
  },
  {
    id: 'job-9',
    title: 'Développeur Backend Python / Django',
    company: 'ScaleUp Technologies',
    city: 'Lille',
    contractType: 'CDI',
    telework: true,
    salaryMin: 48000,
    salaryMax: 58000,
    publishedDate: '2026-06-03',
    experienceLevel: 'Intermédiaire',
    shortDescription: 'Concevez des API ultra-performantes et sécurisées pour notre écosystème e-commerce.',
    description: 'Vos missions principales seront de concevoir et faire évoluer notre architecture backend en Python. Vous optimiserez les requêtes SQL, mettrez en cache les données avec Redis, et assurerez la scalabilité de l\'infrastructure face aux pics de connexion saisonniers.',
    requirements: ['Python', 'Django', 'PostgreSQL', 'Redis', 'API REST', 'Celery'],
    status: 'active'
  },
  {
    id: 'job-10',
    title: 'Responsable Marketing Digital & Growth Hacker',
    company: 'Boost Agency',
    city: 'Strasbourg',
    contractType: 'Freelance',
    telework: true,
    salaryMin: 40000,
    salaryMax: 60000,
    publishedDate: '2026-06-01',
    experienceLevel: 'Senior',
    shortDescription: 'Mettez en œuvre des stratégies d\'acquisition agressives pour booster nos leads entrants de 300%.',
    description: 'Nous recherchons un as du growth hacking pour orchestrer nos campagnes payantes (SEA, Social Ads), optimiser notre SEO naturel, et créer des funnels de conversion hautement performants. Vous analyserez les métriques d\'acquisition quotidiennement et ajusterez les budgets en conséquence.',
    requirements: ['Google Ads', 'SEO', 'Copywriting', 'Cold Emailing', 'Zapier', 'Webflow'],
    status: 'active'
  },
  {
    id: 'job-11',
    title: 'Ingénieur Sécurité Informatique / Pentester',
    company: 'Securica',
    city: 'Paris',
    contractType: 'CDI',
    telework: true,
    salaryMin: 65000,
    salaryMax: 80000,
    publishedDate: '2026-06-04',
    experienceLevel: 'Expert',
    shortDescription: 'Identifiez les vulnérabilités de nos systèmes critiques avant qu\'elles ne soient exploitées.',
    description: 'En tant qu\'expert en cybersécurité, vous mènerez des audits de sécurité de type boîte noire, grise ou blanche sur nos infrastructures physiques et nos applications web. Vous rédigerez des rapports d\'intrusion détaillés et guiderez les équipes de développement dans la remédiation de failles OWASP Top 10.',
    requirements: ['Penetration Testing', 'OWASP', 'Metasploit', 'Wireshark', 'Burp Suite', 'Linux'],
    status: 'active'
  },
  {
    id: 'job-12',
    title: 'Stagiaire en Recrutement et Marque Employeur',
    company: 'Strongtech Solutions',
    city: 'Paris',
    contractType: 'Stage',
    telework: false,
    salaryMin: 12000, // 1000 EUR / month basis
    salaryMax: 15000,
    publishedDate: '2026-06-09',
    experienceLevel: 'Junior',
    shortDescription: 'Rejoignez notre équipe RH pour une mission opérationnelle enrichissante de 6 mois.',
    description: 'Vous assisterez l\'équipe RH sur l\'ensemble du sourcing de candidats, la rédaction d\'offres attractives, le tri des CV, et la planification des entretiens. Vous serez également largement impliqué dans la communication de nos événements d\'entreprise sur LinkedIn.',
    requirements: ['LinkedIn Sourcing', 'Communication', 'Esprit d\'équipe', 'Canva', 'Bureautique'],
    status: 'active'
  },
  {
    id: 'job-13',
    title: 'Développeur Mobile Flutter',
    company: 'Nomad Apps',
    city: 'Rennes',
    contractType: 'CDI',
    telework: true,
    salaryMin: 45000,
    salaryMax: 55000,
    publishedDate: '2026-06-02',
    experienceLevel: 'Intermédiaire',
    shortDescription: 'Développez des applications mobiles multiplateformes magnifiques à partir d\'une codebase unique.',
    description: 'Au sein de notre équipe Mobile, vous serez chargé de concevoir et d\'intégrer de nouvelles fonctionnalités de géolocalisation et de messagerie instantanée dans nos applications Flutter iOS et Android. Vous veillerez à l\'excellence du code et au respect des guidelines d\'Apple et Google.',
    requirements: ['Flutter', 'Dart', 'React Native', 'SQLite', 'Firebase', 'APIs'],
    status: 'active'
  },
  {
    id: 'job-14',
    title: 'Responsable Support Client (Customer Success Manager)',
    company: 'SatisFy SA',
    city: 'Nice',
    contractType: 'CDI',
    telework: true,
    salaryMin: 34000,
    salaryMax: 40000,
    publishedDate: '2026-06-05',
    experienceLevel: 'Junior',
    shortDescription: 'Accompagnez l\'ensemble de nos utilisateurs pour garantir leur satisfaction et réduire l\'attrition.',
    description: 'En tant que pilier de notre centre de satisfaction client, vos journées seront rythmées par la résolution d\'incidents, la formation de nos nouveaux clients par visioconférence, et la centralisation des retours d\'expérience utilisateur pour guider les choix de l\'équipe produit.',
    requirements: ['Gestion de la relation client', 'Empathie', 'Zendesk', 'Intercom', 'Excellente élocution'],
    status: 'active'
  },
  {
    id: 'job-15',
    title: 'Architecte Web & Logiciel Senior',
    company: 'Tech Genesis',
    city: 'Lyon',
    contractType: 'CDI',
    telework: true,
    salaryMin: 75000,
    salaryMax: 90000,
    publishedDate: '2026-06-01',
    experienceLevel: 'Expert',
    shortDescription: 'Dessinez l\'architecture de nos portails web de demain sur des technologies micro-services résilientes.',
    description: 'Votre rôle est central : définir les standards de développement technologiques, concevoir la structure des bases de données hautement répliquées, faire l\'intermédiaire entre les tech-leads et les directeurs produits, et valider la faisabilité technique lors des arbitrages stratégiques.',
    requirements: ['Micro-services', 'Docker / Kubernetes', 'PostgreSQL / NoSQL', 'System Design', 'Kafka', 'Go / Node.js'],
    status: 'active'
  },
  {
    id: 'job-16',
    title: 'Consultant en Recrutement Independent Freelance',
    company: 'Strongtech Solutions',
    city: 'Paris',
    contractType: 'Freelance',
    telework: true,
    salaryMin: 60000,
    salaryMax: 80000,
    publishedDate: '2026-06-08',
    experienceLevel: 'Senior',
    shortDescription: 'Prenez en main la recherche de profils Tech hautement pénuriques pour notre compte.',
    description: 'Nous cherchons un recruteur de choc en freelance pour cibler de manière personnalisée et attirer les meilleurs profils techniques (Architectes, Lead Devs, Cloud Security experts) sur le marché francophone. Facturation attractive au succès.',
    requirements: ['Chasse de tête', 'Négociation', 'Grand Réseau IT', 'LinkedIn Recruiter'],
    status: 'active'
  },
  {
    id: 'job-17',
    title: 'Developpeur Backend Java Spring Boot',
    company: 'Finance Core',
    city: 'Casablanca',
    contractType: 'CDI',
    telework: false,
    salaryMin: 22000, // expressed annually (fictive scale matching local currencies / comparable index)
    salaryMax: 30000,
    publishedDate: '2026-06-09',
    experienceLevel: 'Intermédiaire',
    shortDescription: 'Développez des solutions bancaires résilientes sur l\'architecture Java de référence.',
    description: 'Vous rejoindrez le pôle Core Banking pour concevoir, tester et intégrer des modules d\'authentification forte et de transactions sécurisées. Vous respecterez des normes de performances extrêmes et travaillerez en environnement multi-threads.',
    requirements: ['Java 17', 'Spring Boot', 'Hibernate', 'Oracle DB', 'JUnit', 'Jenkins'],
    status: 'active'
  },
  {
    id: 'job-18',
    title: 'Product Designer (Figma Maestro)',
    company: 'Creative Labs',
    city: 'Casablanca',
    contractType: 'CDI',
    telework: true,
    salaryMin: 20000,
    salaryMax: 28000,
    publishedDate: '2026-06-03',
    experienceLevel: 'Senior',
    shortDescription: 'Prenez les rênes de la modernité esthétique et ergonomique de notre application phare.',
    description: 'Creative Labs cherche un profil capable d\'allier l\'art de l\'ergonomie à des visuels saisissants. Vous mènerez des ateliers de cocreation, animerez nos interfaces de manière interactive, et réinventerez le futur des tableaux de bord financiers simplifiés.',
    requirements: ['Figma Expert', 'Framer / CSS motion', 'Design System', 'UI Design', 'Storytelling'],
    status: 'active'
  },
  {
    id: 'job-19',
    title: 'Ingénieur Data Engineer Senior / Snowflake',
    company: 'Insight Analytics',
    city: 'Rabat',
    contractType: 'CDI',
    telework: true,
    salaryMin: 35000,
    salaryMax: 48000,
    publishedDate: '2026-06-06',
    experienceLevel: 'Senior',
    shortDescription: 'Bâtissez des pipelines de données d\'une robustesse absolue avec Snowflake et dbt.',
    description: 'Nous recherchons un ingénieur de données senior capable d\'optimiser notre data lake et de concevoir des flux ETL/ELT hautement performants de plusieurs téraoctets par jour. Vous serez responsable de la gouvernance de la donnée et des temps de réponse d\'interrogation.',
    requirements: ['Snowflake', 'dbt', 'Python', 'Apache Spark', 'SQL Server', 'Airflow'],
    status: 'active'
  },
  {
    id: 'job-20',
    title: 'Consultant SEO & SEA Booster',
    company: 'Traffic Kings',
    city: 'Marseille',
    contractType: 'Alternance',
    telework: true,
    salaryMin: 15000,
    salaryMax: 19000,
    publishedDate: '2026-06-07',
    experienceLevel: 'Junior',
    shortDescription: 'Participez au renforcement du trafic naturel et payant de nos e-commerces partenaires.',
    description: 'Vous travaillerez en binôme avec notre Head of Marketing pour analyser les mots-clés stratégiques, rédiger des fiches produits optimisés SEO, configurer des campagnes d\'enchères au clic (Google & Bing Ads), et soumettre des rapports d\'audience hebdomadaires.',
    requirements: ['SEO On-page', 'Google Analytics', 'Ahrefs / Semrush', 'Google Ads', 'Rigueur analytique'],
    status: 'active'
  }
];

export const initialCandidateProfile: CandidateProfile = {
  id: 'cand-user',
  fullName: 'Yassine Belkacem',
  email: 'yassine.belkacem@gmail.com',
  phone: '+33 6 12 34 56 78',
  address: '12 Rue de la Passerelle, 75010 Paris',
  photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
  title: 'Développeur Full Stack React & Node.js',
  seniority: 'Intermédiaire',
  bio: 'Passionné par le développement web et le design de logiciels d\'automatisation. J\'ai 4 ans d\'expérience dans l\'élaboration d\'applications SaaS élégantes, robustes et hautement maintenables.',
  skills: ['React.js', 'TypeScript', 'Node.js', 'Express', 'Tailwind CSS', 'PostgreSQL', 'Docker', 'Git'],
  education: [
    {
      degree: 'Master en Ingénierie Logicielle',
      school: 'Sorbonne Université / EPITA',
      year: '2019 - 2021'
    },
    {
      degree: 'Licence en Informatique Fondamentale',
      school: 'Université de Lille',
      year: '2016 - 2019'
    }
  ],
  experience: [
    {
      role: 'Développeur Full Stack',
      company: 'WebPulse Agency',
      duration: '2022 - 2025 (3 ans)',
      description: 'Conception et maintenance d\'applications de gestion de factures. Migration de l\'architecture vers Next.js et réduction du temps de chargement de 40%.'
    },
    {
      role: 'Développeur Frontend Junior',
      company: 'StartUp Studio',
      duration: '2021 - 2022 (1 an)',
      description: 'Intégration d\'interfaces pixel-perfect sur Figma, collaboration étroite avec les designers UI et intégration de tests unitaires.'
    }
  ],
  languages: [
    { language: 'Français', level: 'Langue Maternelle' },
    { language: 'Anglais', level: 'Professionnel (C1)' },
    { language: 'Espagnol', level: 'Débutant (A2)' }
  ],
  cvFileName: 'CV_Yassine_Belkacem_Developpeur_Web.pdf'
};

export const initialCandidatesList: CandidateProfile[] = [
  { ...initialCandidateProfile },
  {
    id: 'cand-1',
    fullName: 'Sophie Martin',
    email: 'sophie.martin@hr-innovate.fr',
    phone: '+33 6 98 76 54 32',
    address: '45 Rue de la République, Lyon',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    title: 'Consultante Recrutement Tech & RH',
    seniority: 'Senior',
    bio: 'Experte en sourcing et recrutement IT avec 6 ans d\'expérience au sein de cabinets prestigieux. Forte orientation vers l\'onboarding humain.',
    skills: ['Sourcing', 'LinkedIn Recruiter', 'Onboarding', 'Marque Employeur', 'Fiche de poste'],
    education: [
      { degree: 'Master 2 Psychologie du Travail & RH', school: 'Université Lumière Lyon 2', year: '2017 - 2019' }
    ],
    experience: [
      { role: 'Chargée de Recrutement Senior', company: 'Global Search France', duration: '2021 - 2025', description: 'Chasse de tête de profils exécutifs et ingénieurs de haut niveau.' }
    ],
    languages: [
      { language: 'Français', level: 'Maternelle' },
      { language: 'Anglais', level: 'Courant' }
    ],
    cvFileName: 'CV_Sophie_Martin_Recrutement.pdf'
  },
  {
    id: 'cand-2',
    fullName: 'Marc Fontaine',
    email: 'marc.fontaine@devops-expert.com',
    phone: '+33 7 45 61 24 99',
    address: '8 Place de la Comédie, Montpellier',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    title: 'Consultant DevOps Cloud AWS',
    seniority: 'Expert',
    bio: 'Architecte cloud passionné par l\'automatisation de l\'infrastructure, la sécurité des données et le provisionnement Declarative (Terraform).',
    skills: ['AWS', 'Kubernetes', 'Terraform', 'CI/CD', 'GitLab', 'Docker', 'Bash', 'Prometheus'],
    education: [
      { degree: 'Diplôme d\'Ingénieur Informatique', school: 'INSA Toulouse', year: '2012 - 2017' }
    ],
    experience: [
      { role: 'Architecte Infra / Team Lead Cloud', company: 'CloudWay SAS', duration: '2019 - 2025', description: 'Migration de 12 pipelines critiques vers AWS de manière sécurisée et supervision d\'une équipe de 4 DevOps.' }
    ],
    languages: [
      { language: 'Français', level: 'Maternelle' },
      { language: 'Anglais', level: 'Excellent (Bilingue)' }
    ],
    cvFileName: 'CV_Marc_Fontaine_Devops_Architect.pdf'
  },
  {
    id: 'cand-3',
    fullName: 'Amine El Alami',
    email: 'amine.ami@gmail.com',
    phone: '+212 6 61 77 88 99',
    address: 'Gauthier, Casablanca',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200', // Women photo, let's look at another
    title: 'UI/UX Designer & Product Specialist',
    seniority: 'Intermédiaire',
    bio: 'Designer d\'expérience mobile et web, obsédée par la clarté visuelle et la simplicité du parcours utilisateur.',
    skills: ['Figma', 'Adobe XD', 'Prototypage', 'Design System', 'A/B Testing', 'HTML/CSS integration'],
    education: [
      { degree: 'Master en Design d\'Interaction', school: 'Ecole de Design Casablanca', year: '2018 - 2020' }
    ],
    experience: [
      { role: 'UX UI Lead Designer', company: 'Creative Agency Casablanca', duration: '2021 - 2024', description: 'Création d\'interfaces pour 5 applications bancaires d\'importance nationale.' }
    ],
    languages: [
      { language: 'Arabe', level: 'Langue Maternelle' },
      { language: 'Français', level: 'Courant' },
      { language: 'Anglais', level: 'Professionnel' }
    ],
    cvFileName: 'CV_Amine_UXUI_Design.pdf'
  },
  {
    id: 'cand-4',
    fullName: 'Camille Dubois',
    email: 'camille.dubois@esecure.fr',
    phone: '+33 6 45 11 22 33',
    address: '90 Avenue d\'Italie, Paris',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200',
    title: 'Ingénieure en Cybersécurité & Audit',
    seniority: 'Senior',
    bio: 'Spécialiste de tests d\'intrusion applicatifs et physiques, certifiée CEH. Engagée dans la pédagogie de la sécurité auprès des équipes techniques.',
    skills: ['Pentesting', 'Securité Web', 'OWASP Code Review', 'Metasploit', 'Python Sec', 'Linux Admin'],
    education: [
      { degree: 'Diplôme de Spécialisation Cybersécurité', school: 'Télécom Paris', year: '2016-2018' }
    ],
    experience: [
      { role: 'Pentester et Consultante Sec', company: 'Orange Cyberdefense', duration: '2019-2025', description: 'Réalisation de 50+ audits applicatifs à forte contrainte réglementaire.' }
    ],
    languages: [
      { language: 'Français', level: 'Maternelle' },
      { language: 'Anglais', level: 'Courant' }
    ],
    cvFileName: 'CV_Camille_Dubois_Cyber_Security.pdf'
  }
];

export const initialApplications: Application[] = [
  {
    id: 'app-1',
    jobId: 'job-1',
    jobTitle: 'Développeur Full Stack Senior React & Node.js',
    company: 'Strongtech Solutions',
    candidateId: 'cand-user',
    candidateName: 'Yassine Belkacem',
    candidateEmail: 'yassine.belkacem@gmail.com',
    dateApplied: '2026-06-05',
    status: 'Entretien',
    coverLetter: 'Bonjour, très enthousiaste à l\'idée de rejoindre l\'équipe de Strongtech Solutions et de concevoir des architectures modernes en React et Node.js. Mon parcours de développeur full-stack est en parfaite adéquation avec vos exigences.',
    cvFileName: 'CV_Yassine_Belkacem_Developpeur_Web.pdf'
  },
  {
    id: 'app-2',
    jobId: 'job-2',
    jobTitle: 'Chef de Projet RH & Recrutement',
    company: 'Innovate Group',
    candidateId: 'cand-1',
    candidateName: 'Sophie Martin',
    candidateEmail: 'sophie.martin@hr-innovate.fr',
    dateApplied: '2026-06-08',
    status: 'Reçue',
    coverLetter: 'Bonjour, j\'ai le plaisir de soumettre ma candidature. Mon expérience de 6 ans en recrutement de profils tech me permettra d\'être immédiatement opérationnelle et de gérer vos recrutements les plus stratégiques.',
    cvFileName: 'CV_Sophie_Martin_Recrutement.pdf'
  },
  {
    id: 'app-3',
    jobId: 'job-3',
    jobTitle: 'Consultant Cloud DevOps AWS',
    company: 'Skyward Cloud Services',
    candidateId: 'cand-2',
    candidateName: 'Marc Fontaine',
    candidateEmail: 'marc.fontaine@devops-expert.com',
    dateApplied: '2026-06-07',
    status: 'En cours',
    coverLetter: 'Expert DevOps certifié AWS Solutions Architect, j\'aimerais offrir mes compétences en infrastructure immutable et pipelines CI/CD sécurisés à l\'équipe de Skyward Cloud Services.',
    cvFileName: 'CV_Marc_Fontaine_Devops_Architect.pdf'
  },
  {
    id: 'app-4',
    jobId: 'job-4',
    jobTitle: 'UX/UI Designer Talentueux',
    company: 'Pixel Engine',
    candidateId: 'cand-3',
    candidateName: 'Amine El Alami',
    candidateEmail: 'amine.ami@gmail.com',
    dateApplied: '2026-06-05',
    status: 'Acceptée',
    coverLetter: 'Ayant repensé plusieurs applications complexes à haute fidélité visuelle, je souhaite rejoindre Pixel Engine en tant qu\'UX/UI Designer. Mon portfolio est joint à ma demande.',
    cvFileName: 'CV_Amine_UXUI_Design.pdf'
  }
];

export const initialCalendarEvents: CalendarEvent[] = [
  {
    id: 'evt-1',
    title: 'Entretien Technique - Yassine Belkacem',
    type: 'interview',
    date: '2026-06-12',
    time: '14:30',
    candidateName: 'Yassine Belkacem',
    description: 'Entretien technique portant sur React, architecture NodeJS, les performances web, et résolution algorithmique.'
  },
  {
    id: 'evt-2',
    title: 'Réunion Validation RH - Projet Innovate',
    type: 'meeting',
    date: '2026-06-11',
    time: '10:00',
    description: 'Calibrage final des offres d\'acquisition de talents avec les directeurs techniques.'
  },
  {
    id: 'evt-3',
    title: 'Session recrutement Collective - DevOps',
    type: 'session',
    date: '2026-06-18',
    time: '09:00',
    description: 'Accueil de 4 candidats DevOps présélectionnés dans nos locaux de Paris pour des ateliers techniques et relationnels.'
  },
  {
    id: 'evt-4',
    title: 'Entretien Final Fit - Camille Dubois',
    type: 'interview',
    date: '2026-06-15',
    time: '16:00',
    candidateName: 'Camille Dubois',
    description: 'Évaluation finale de l\'adéquation culturelle et négociation contractuelle pour le poste de Pentester Cybersécurité.'
  }
];

export const initialNotifications: Notification[] = [
  {
    id: 'notif-1',
    title: 'Nouvelle candidature reçue',
    description: 'Sophie Martin a postulé pour le poste de "Chef de Projet RH & Recrutement".',
    date: '2026-06-08',
    read: false,
    type: 'application'
  },
  {
    id: 'notif-2',
    title: 'Entretien programmé',
    description: 'Entretien technique avec Yassine Belkacem fixé au vendredi 12 Juin à 14h30.',
    date: '2026-06-07',
    read: false,
    type: 'interview'
  },
  {
    id: 'notif-3',
    title: 'Offre d\'emploi expirée',
    description: 'L\'offre de Développeur PHP chez WebCorp est arrivée au terme de sa publication.',
    date: '2026-06-05',
    read: true,
    type: 'job_expired'
  },
  {
    id: 'notif-4',
    title: 'Nouveau candidat inscrit',
    description: 'Marc Fontaine a rejoint StrongtechRH en tant que Consultant DevOps Expert.',
    date: '2026-06-07',
    read: true,
    type: 'new_candidate'
  }
];

export const initialChatSessions: ChatSession[] = [
  {
    id: 'chat-1',
    candidateId: 'cand-user',
    candidateName: 'Yassine Belkacem',
    candidatePhotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    candidateTitle: 'Développeur Full Stack React & Node.js',
    lastMessage: 'Bonjour ! Merci beaucoup, je serai présent à l\'appel de vendredi.',
    lastUpdated: '12:05',
    unread: true,
    messages: [
      {
        id: 'm1',
        senderId: 'hr',
        senderName: 'Équipe Recrutement Strongtech',
        text: 'Bonjour Yassine, nous avons bien reçu votre candidature et votre parcours nous intéresse vivement. Seriez-vous libre pour un entretien technique ce vendredi à 14h30 via Teams ?',
        timestamp: '11:58'
      },
      {
        id: 'm2',
        senderId: 'candidate',
        senderName: 'Yassine Belkacem',
        text: 'Bonjour ! Merci beaucoup, je serai présent à l\'appel de vendredi. J\'ai mis à jour mon CV sur la plateforme pour intégrer mon dernier projet Docker.',
        timestamp: '12:05'
      }
    ]
  },
  {
    id: 'chat-2',
    candidateId: 'cand-1',
    candidateName: 'Sophie Martin',
    candidatePhotoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    candidateTitle: 'Consultante Recrutement Tech & RH',
    lastMessage: 'Y a-t-il un test technique prévu pour ce recrutement ?',
    lastUpdated: '09:12',
    unread: false,
    messages: [
      {
        id: 'm3',
        senderId: 'candidate',
        senderName: 'Sophie Martin',
        text: 'Bonjour l\'équipe RH de Strongtech. Je viens de soumettre ma candidature pour l\'offre d\'Innovate Group. Y a-t-il un test technique prévu pour ce recrutement ?',
        timestamp: '09:12'
      }
    ]
  },
  {
    id: 'chat-3',
    candidateId: 'cand-2',
    candidateName: 'Marc Fontaine',
    candidatePhotoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    candidateTitle: 'Consultant DevOps Cloud AWS',
    lastMessage: 'Je suis ouvert à un début de mission immédiat en télétravail complet.',
    lastUpdated: 'Hier',
    unread: false,
    messages: [
      {
        id: 'm4',
        senderId: 'candidate',
        senderName: 'Marc Fontaine',
        text: 'Bonjour. J\'ai déposé ma candidature pour le poste DevOps Cloud. Sachez que je suis disponible immédiatement pour démarrer un projet, en télétravail complet ou déplacements ponctuels.',
        timestamp: '15:22'
      },
      {
        id: 'm5',
        senderId: 'hr',
        senderName: 'Équipe Recrutement Strongtech',
        text: 'Merci Marc pour cette précision. Notre client Skyward étudie les profils cette semaine, nous vous tenons au courant rapidement.',
        timestamp: '17:00'
      },
      {
        id: 'm6',
        senderId: 'candidate',
        senderName: 'Marc Fontaine',
        text: 'Entendu, parfait. Je reste à votre entière disposition.',
        timestamp: '17:15'
      }
    ]
  }
];
